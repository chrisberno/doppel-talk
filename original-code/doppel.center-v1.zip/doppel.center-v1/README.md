# Doppel Center

> Provider-agnostic voice talent gallery for IVR and contact center applications

Doppel Center is a web application that helps developers and contact center professionals discover, preview, and configure text-to-speech voices for Twilio-based IVR systems. It provides a unified interface for browsing voices across multiple providers, testing them with custom scripts, and exporting ready-to-use configurations.

## Features

- **Voice Library**: 16+ curated Twilio/Amazon Polly voices across 6 languages
- **Real-time Preview**: Listen to sample audio or generate custom script previews
- **Multi-format Export**: TwiML, Twilio Studio JSON, and API code snippets
- **Provider Abstraction**: Architecture supports multiple TTS providers
- **Pass-through Credentials**: Secure model where credentials are never stored server-side

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│    Frontend     │────▶│    Backend      │────▶│   Providers     │
│   (Vanilla JS)  │     │   (Express)     │     │  (Twilio/Polly) │
│                 │     │                 │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
         │                      │
         │                      │
    Voice Gallery          Voice Registry
    Audio Player           TTS Service
    Export Modal           Export Service
```

## Quick Start

### Prerequisites

- Node.js 18.0.0 or higher
- npm or yarn
- Twilio account (for TTS generation)
- AWS credentials (for Amazon Polly integration)

### Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd doppel-center
   ```

2. Install backend dependencies:
   ```bash
   cd backend
   npm install
   ```

3. Configure environment:
   ```bash
   cp ../.env.example .env
   ```

4. Edit `.env` with your settings (see [Configuration](#configuration) below)

5. Start the server:
   ```bash
   npm run dev
   ```

6. Open your browser to `http://localhost:3000`

### Configuration

Create a `.env` file in the `backend` directory with the following variables:

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `PORT` | No | `3000` | Server port |
| `NODE_ENV` | No | `development` | Environment mode |
| `ALLOWED_ORIGINS` | No | `localhost:8080,localhost:3000` | Comma-separated CORS origins |
| `AWS_ACCESS_KEY_ID` | Yes* | - | AWS access key for Polly |
| `AWS_SECRET_ACCESS_KEY` | Yes* | - | AWS secret key for Polly |
| `AWS_REGION` | No | `us-east-1` | AWS region |

*Required for TTS audio generation

### Running the Application

**Development** (with auto-reload):
```bash
cd backend
npm run dev
```

**Production**:
```bash
cd backend
npm start
```

## Project Structure

```
doppel-center/
├── backend/                    # Express.js API server
│   ├── data/                   # Voice catalog data
│   │   └── voices.json         # Voice definitions
│   ├── routes/                 # API route handlers
│   │   ├── voices.js           # Voice listing endpoints
│   │   ├── generate.js         # TTS generation endpoint
│   │   └── export.js           # Export configuration endpoint
│   ├── services/               # Business logic
│   │   ├── voiceRegistry.js    # Voice data management
│   │   ├── ttsService.js       # Provider abstraction layer
│   │   ├── exportService.js    # Export generation
│   │   └── providers/          # Provider implementations
│   │       └── twilio.js       # Twilio/Polly provider
│   ├── server.js               # Express app entry point
│   ├── API.md                  # API reference documentation
│   └── README.md               # Backend-specific docs
├── frontend/                   # Static frontend files
│   ├── index.html              # Main application page
│   ├── css/                    # Stylesheets
│   └── js/                     # JavaScript modules
│       ├── app.js              # Main application logic
│       ├── audio.js            # Audio player module
│       └── export.js           # Export modal module
├── BizOps/                     # Business documentation
├── .env.example                # Environment template
├── SPEC.md                     # Technical specification
└── README.md                   # This file
```

## API Documentation

See [backend/API.md](backend/API.md) for comprehensive API reference including:

- All endpoints with request/response examples
- Error codes and handling
- Authentication model
- Voice data structure

### Quick API Reference

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check |
| `/api/voices` | GET | List all voices (with filters) |
| `/api/voices/:id` | GET | Get voice by ID |
| `/api/providers` | GET | List providers |
| `/api/generate` | POST | Generate TTS audio |
| `/api/validate-credentials` | POST | Validate Twilio credentials |
| `/api/export/:format` | POST | Export voice configuration |

## Deployment

### Production Hosting

| Component | Host | Account | URL |
|-----------|------|---------|-----|
| **API** | Render | chrisberno | https://doppel.center |
| **Frontend Demo** | Vercel | chris-2413 | https://voice-demos.doppel.center |
| **DNS** | Spaceship | chrisberno | doppel.center |

**Architecture**: The API and frontend are deployed separately. The frontend is a static demo that calls the API at `https://doppel.center/api`.

### Environment Variables

For production, ensure these are set:

```bash
NODE_ENV=production
PORT=3000
ALLOWED_ORIGINS=https://your-domain.com
AWS_ACCESS_KEY_ID=your_aws_key
AWS_SECRET_ACCESS_KEY=your_aws_secret
AWS_REGION=us-east-1
```

### Deployment Options

#### Local/Development
```bash
npm run dev
```

#### Production with PM2
```bash
npm install -g pm2
pm2 start backend/server.js --name doppel-center
pm2 save
```

#### Production with systemd

Create `/etc/systemd/system/doppel-center.service`:
```ini
[Unit]
Description=Doppel Center API Server
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/path/to/doppel-center/backend
ExecStart=/usr/bin/node server.js
Restart=on-failure
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

#### Docker

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY backend/package*.json ./
RUN npm ci --only=production
COPY backend/ ./
COPY frontend/ ./frontend/
EXPOSE 3000
CMD ["node", "server.js"]
```

#### Cloud Platforms

The application is compatible with:
- **Heroku**: Add `Procfile` with `web: node backend/server.js`
- **Railway**: Automatic detection from package.json
- **Render**: Configure as Web Service
- **AWS/GCP/Azure**: Deploy as container or VM

### Health Checks

Verify deployment health:
```bash
curl http://your-server:3000/health
# Expected: {"status":"ok"}
```

## Development

### Adding a New Provider

1. Create provider implementation in `backend/services/providers/`:
   ```javascript
   // backend/services/providers/newprovider.js
   module.exports = {
     async generateAudio(voiceId, text, options, credentials) {
       // Implementation
     },
     async validateCredentials(credentials) {
       // Implementation
     },
     async getVoiceMetadata(voiceId) {
       // Implementation
     }
   };
   ```

2. Register in `backend/services/ttsService.js`:
   ```javascript
   const newProvider = require('./providers/newprovider');
   const providerServices = {
     twilio: twilioProvider,
     newprovider: newProvider
   };
   ```

3. Add provider metadata in `backend/services/voiceRegistry.js`

4. Add voices to `backend/data/voices.json`

### Code Style

- Backend: CommonJS modules, Express patterns
- Frontend: Vanilla JavaScript, ES6+ features
- No TypeScript (intentional for simplicity)

## Troubleshooting

### Common Issues

**CORS Errors**
- Ensure `ALLOWED_ORIGINS` includes your frontend URL
- In development, `NODE_ENV=development` allows all origins

**Credential Validation Fails**
- Verify Account SID starts with "AC" and is 34 characters
- Verify Auth Token is exactly 32 characters
- Check credentials at https://console.twilio.com

**TTS Generation Fails with AWS Error**
- Ensure `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` are set
- Verify IAM user has `polly:SynthesizeSpeech` permission
- Check `AWS_REGION` matches your Polly setup

**Audio Doesn't Play**
- Check browser console for errors
- Verify the voice ID exists in the registry
- Ensure credentials are valid

## Documentation

- [Technical Specification](SPEC.md) - Detailed architecture and design
- [API Reference](backend/API.md) - Complete API documentation
- [Business Model](BizOps/BUSINESS-MODEL.md) - Revenue and pricing strategy
- [Strategic Vision](BizOps/STRATEGIC-VISION.md) - Product roadmap
- [Decisions Log](BizOps/DECISIONS-LOG.md) - Architecture decisions

## License

MIT License - see LICENSE file for details.
