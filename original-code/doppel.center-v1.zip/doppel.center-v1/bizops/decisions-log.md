# Doppel Center Decisions Log

*Last Updated: December 27, 2024 (Evening)*

---

## About This Document

This log captures strategic decisions made during the development of Doppel Center. Each entry includes the decision itself, the rationale behind it, alternatives considered, and future considerations.

**Format:** Decisions are logged chronologically with unique identifiers for cross-referencing.

---

## Decision Index

| ID | Decision | Date |
|----|----------|------|
| [DEC-001](#dec-001-platform-architecture) | Platform Architecture | Dec 2024 |
| [DEC-002](#dec-002-customer-segmentation) | Customer Segmentation | Dec 2024 |
| [DEC-003](#dec-003-credential-model) | Three-Tier Credential Model | Dec 2024 |
| [DEC-004](#dec-004-revenue-model) | Revenue Model | Dec 2024 |
| [DEC-005](#dec-005-pricing-philosophy) | Pricing Philosophy | Dec 2024 |
| [DEC-006](#dec-006-audio-storage-strategy) | Audio Storage Strategy | Dec 2024 |
| [DEC-007](#dec-007-provider-priority) | Provider Priority | Dec 2024 |
| [DEC-008](#dec-008-voice-metadata-strategy) | Voice Metadata Strategy | Dec 2024 |
| [DEC-009](#dec-009-production-deployment) | Production Deployment (Render) | Dec 27, 2024 |
| [DEC-010](#dec-010-first-customer-integration) | First Customer Integration (Connie) | Dec 27, 2024 |
| [DEC-011](#dec-011-house-account-first) | House Account First Strategy | Dec 27, 2024 |
| [DEC-012](#dec-012-developer-first-model) | Developer-First Model | Dec 27, 2024 |
| [DEC-013](#dec-013-frontend-api-separation) | Frontend/API Separation | Dec 27, 2024 |

---

## DEC-001: Platform Architecture

**Date:** December 2024

**Decision:** Build Doppel Center as an API-first, microservices-model platform that is embeddable via iframe or API. Consuming apps authenticate their own users and call Doppel with their API key.

**Rationale:**
- **Single Responsibility:** Doppel does one thing well—voice/TTS management—rather than becoming a bloated platform
- **Integration Simplicity:** Partners don't need to change their auth model; they just add an API key
- **Composability:** Clean microservice boundaries enable future ecosystem expansion
- **Ownership Clarity:** Consuming apps own their user relationships; Doppel owns voice capability

**Alternatives Considered:**
1. **Full-stack platform with user auth:** Rejected—adds complexity, competes with partners
2. **SDK-only distribution:** Rejected—limits reach, requires more partner engineering effort
3. **White-label SaaS:** Partially adopted via iframe embedding, but API remains primary

**Future Considerations:**
- May need webhook support for async operations (long clone processing, etc.)
- Consider GraphQL alongside REST for complex queries
- Evaluate WebSocket for real-time voice preview streaming

**Cross-Reference:** [BUSINESS-MODEL.md - Platform Architecture](./BUSINESS-MODEL.md#platform-architecture)

---

## DEC-002: Customer Segmentation

**Date:** December 2024

**Decision:** Serve two distinct customer segments—B2B (platform integrators) and B2C (direct users, "nephew scenario")—with differentiated experiences and billing models.

**Rationale:**
- **Market Reality:** Both segments exist and have valid needs, but they're fundamentally different
- **B2B Value:** API reliability, documentation, white-label capability
- **B2C Value:** Simplicity, single bill, no technical prerequisites
- **Revenue Diversity:** Multiple segments reduce dependency on any single customer type

**Alternatives Considered:**
1. **B2B Only:** Rejected—leaves money on table, nephew scenario is real and large
2. **B2C Only:** Rejected—misses enterprise scale and recurring platform revenue
3. **Single Experience for Both:** Rejected—would compromise both experiences

**Future Considerations:**
- B2C may require dedicated marketing/onboarding investment
- Consider B2B2C model where partners white-label the B2C experience
- Monitor segment mix to ensure neither is neglected

**Cross-Reference:** [BUSINESS-MODEL.md - Customer Segments](./BUSINESS-MODEL.md#customer-segments)

---

## DEC-003: Credential Model

**Date:** December 2024

**Decision:** Implement three-tier credential model: Pass-through (creds in request), BYOK (creds stored encrypted), and House Account (Doppel's master creds with customer billing).

**Rationale:**
- **Flexibility Spectrum:** Serves everyone from security-paranoid enterprises to "just make it work" SMBs
- **Pass-through:** Zero trust required from customer, ideal for testing
- **BYOK:** Customer maintains provider relationship, Doppel stores creds securely
- **House Account:** Maximum simplicity for B2C—no provider accounts needed

**Alternatives Considered:**
1. **BYOK Only:** Rejected—excludes B2C entirely
2. **House Account Only:** Rejected—enterprises won't accept markup and lack of control
3. **Pass-through Only:** Rejected—terrible UX for production use
4. **Two-tier (BYOK + House):** Rejected—pass-through valuable for testing/debugging

**Future Considerations:**
- House Account margin must cover credit risk (prepay vs. postpay?)
- BYOK credential encryption key rotation strategy
- May need OAuth integration for providers that support it

**Cross-Reference:** [BUSINESS-MODEL.md - Credential Model](./BUSINESS-MODEL.md#credential-model-three-tier)

---

## DEC-004: Revenue Model

**Date:** December 2024

**Decision:** B2B pays platform fee (customer pays provider directly); B2C pays Doppel everything (usage + markup), Doppel pays providers. Philosophy: "Tool, not telco."

**Rationale:**
- **B2B Alignment:** Enterprises want control of provider relationships and billing
- **B2C Simplicity:** Small businesses want one bill from one vendor
- **Not Competing with Providers:** We add value through UX/intelligence, not markup arbitrage
- **House Account as Convenience:** It's a feature for B2C simplicity, not a core revenue strategy

**Alternatives Considered:**
1. **Markup on All:** Rejected—B2B won't accept unnecessary margin
2. **Platform Fee Only:** Rejected—doesn't serve B2C need for single billing
3. **Pure Usage-Based:** Considered viable, but subscription component provides revenue predictability

**Future Considerations:**
- Volume discounts from providers could improve house account margins
- May need to revisit if B2C segment grows significantly
- Consider revenue share with embedding partners

**Cross-Reference:** [BUSINESS-MODEL.md - Revenue Model](./BUSINESS-MODEL.md#revenue-model)

---

## DEC-005: Pricing Philosophy

**Date:** December 2024

**Decision:** NOT free, NOT freemium. Offer generous trial/sandbox for testing, but if it's valuable enough to use, it's valuable enough to pay for. Price models: pay-per-use or bundles.

**Rationale:**
- **Value Signal:** Price communicates value; free communicates disposability
- **No Artificial Walls:** Freemium frustrates users with feature gates—we want happy customers
- **Generous Trial:** Let users validate fit before committing, but set expectations
- **Sustainable Business:** Free models require massive scale; we're building for sustainable growth

**Alternatives Considered:**
1. **Freemium:** Rejected—artificial feature walls create frustration, not loyalty
2. **Free Tier Forever:** Rejected—attracts users who don't value the product
3. **Enterprise Only (High Price):** Rejected—misses SMB/B2C opportunity
4. **Pure Pay-Per-Use:** Viable, but bundles provide predictability for both sides

**Future Considerations:**
- Define exact trial limits (time-based? usage-based? both?)
- Consider annual discount for predictability
- Monitor conversion rate from trial to paid

**Cross-Reference:** [BUSINESS-MODEL.md - Pricing Philosophy](./BUSINESS-MODEL.md#pricing-philosophy)

---

## DEC-006: Audio Storage Strategy

**Date:** December 2024

**Decision:** Phase 1 (MVP) is on-demand only—generate, return, discard. No audio storage. Future: "Script Management System" with saved scripts, version history, voice associations, one-click regeneration.

**Rationale:**
- **MVP Simplicity:** Storage adds compliance, cost, and complexity—validate core value first
- **On-Demand Works:** For initial use cases, ephemeral audio is sufficient
- **Future Value:** Script Management is a clear Phase 3 value-add, not MVP requirement
- **Compliance Deferral:** Audio storage introduces GDPR/data retention concerns—defer until necessary

**Alternatives Considered:**
1. **Storage from Day 1:** Rejected—premature complexity, unvalidated need
2. **Never Store:** Rejected—clear future value in script management
3. **Optional Storage (User Choice):** Considered for Phase 2, but adds UX complexity

**Future Considerations:**
- Storage costs and pricing model for retained audio
- Retention policies and compliance (how long do we keep?)
- Version history UX—how granular?

**Cross-Reference:** [STRATEGIC-VISION.md - Script Management System](./STRATEGIC-VISION.md#script-management-system-future)

---

## DEC-007: Provider Priority

**Date:** December 2024

**Decision:** Provider integration priority: (1) Twilio/Polly, (2) Doppel Clone/VoiceCraft, (3) ElevenLabs, (4) Hume, (5+) demand-driven.

**Rationale:**
- **Twilio First:** Enterprise trust, immediate IVR value, largest existing market
- **VoiceCraft Second:** Core differentiator—voice cloning. Integrate early even if beta.
- **ElevenLabs Third:** Premium prefab expansion, high-quality synthesis
- **Hume Fourth:** Emotional TTS is differentiated but niche
- **Others:** Let demand guide—no feature checkbox thinking

**Alternatives Considered:**
1. **All Providers Simultaneously:** Rejected—resource constraints, unfocused
2. **ElevenLabs First:** Rejected—less immediate IVR applicability than Twilio
3. **VoiceCraft First:** Considered—differentiator is compelling, but Twilio has existing market

**Future Considerations:**
- VoiceCraft partnership terms and timeline
- Provider API stability and reliability monitoring
- Community requests may reprioritize roadmap

**Cross-Reference:** [BUSINESS-MODEL.md - Provider Strategy](./BUSINESS-MODEL.md#provider-strategy)

---

## DEC-008: Voice Metadata Strategy

**Date:** December 2024

**Decision:** Phase 1 pulls voice metadata from provider APIs. Future: "Voice Casting AI" with JTBD-driven intelligent matching—"I need a [___] voice that [___] so I can [___]"—AI serves 3 curated auditions, selections train the model.

**Rationale:**
- **Phase 1 Reality:** Provider APIs give us basic metadata; that's sufficient for MVP
- **Future Differentiation:** Voice Casting AI is our moat—JTBD matching vs. filter-based selection
- **Data Flywheel:** Every selection trains recommendations—competitors can't catch up
- **UX Revolution:** 3 curated options vs. scrolling through hundreds

**Alternatives Considered:**
1. **Manual Curation Only:** Rejected—doesn't scale, no data flywheel
2. **AI from Day 1:** Rejected—need usage data to train; chicken-and-egg
3. **Pure Filter-Based Forever:** Rejected—table stakes, no differentiation

**Future Considerations:**
- Training data requirements for meaningful AI recommendations
- Cold start problem for new users (use population-level data?)
- Feedback loop design (explicit rating vs. implicit selection?)

**Cross-Reference:** [STRATEGIC-VISION.md - Voice Casting AI](./STRATEGIC-VISION.md#voice-casting-ai)

---

## DEC-009: Production Deployment

**Date:** December 27, 2024

**Decision:** Deploy Doppel Center API to Render.com with custom domain doppel.center, using GitHub auto-deploy from main branch.

**Rationale:**
- **Render vs. Railway:** Previous experience with Railway was problematic; Render offers simpler Express.js deployment
- **Render vs. Vercel:** Vercel optimized for serverless/Next.js; Render better for persistent Express servers
- **Custom Domain:** doppel.center establishes brand identity and provides stable API endpoint
- **Auto-Deploy:** GitHub integration enables rapid iteration without manual deployment steps
- **Flat Pricing:** Predictable costs vs. usage-based surprises

**Implementation Details:**
- Hosting: Render.com (Web Service)
- Domain: doppel.center (DNS via Spaceship)
- SSL: Auto-provisioned via Let's Encrypt
- Deploy trigger: Push to main branch

**CORS Configuration:**
Default allowed origins configured for production security:
- https://doppel.center, https://www.doppel.center
- https://connie.one, https://connie.plus
- https://dutycall.app
- localhost for development

**Cross-Reference:** Infrastructure documentation in techops/

---

## DEC-010: First Customer Integration

**Date:** December 27, 2024

**Decision:** Connie (specifically connie.one) is the first integration customer. Build features for Connie's needs; if valuable to others, Doppel becomes a standalone product.

**Rationale:**
- **Internal First:** Connie is our own platform—we control both sides of the integration
- **Lower Risk:** connie.one (marketing site) before connie.plus (production CPAAS)
- **Real Use Case:** Connie's IVR voice selection needs are representative of the market
- **Dogfooding:** Using our own product reveals friction points faster than external feedback

**Implementation:**
- Created `/voice-interface` page on connie.one
- Fetches voices from doppel.center/api/voices
- Displays in clean table format with audio preview
- Deployed to AWS Amplify

**Future Path:** If Doppel delivers value to Connie, extend to DutyCall, then third-party platforms.

**Cross-Reference:** [DEC-001](#dec-001-platform-architecture) - API-first model enables this integration pattern

---

## DEC-011: House Account First Strategy

**Date:** December 27, 2024

**Decision:** Implement House Account mode first for TTS generation. BYOK becomes an "escape hatch" for enterprises, not the primary path.

**Rationale:**
- **Build Value First:** Can't learn what customers need if they can't use the product
- **No Metering Yet:** Billing infrastructure is premature before feature value is proven
- **doppel.center as Lab Rat:** The retail frontend at doppel.center is our testing ground
- **Simplicity:** House Account is one less barrier to usage and feedback

**Implementation Approach:**
1. Modify `/api/generate` to accept requests without credentials
2. When no credentials provided, use server-side AWS credentials directly
3. Skip Twilio credential validation (we're using our own AWS Polly setup)
4. Return `mode: 'house_account'` in response for transparency

**Credential Flow:**
```
Request with credentials → Pass-through mode (validate Twilio, use AWS)
Request without credentials → House Account mode (skip validation, use AWS)
```

**Deferred:**
- Usage metering
- Rate limiting
- Billing infrastructure

**Cross-Reference:** [DEC-003](#dec-003-credential-model) - Evolution of three-tier model

---

## DEC-012: Developer-First Model

**Date:** December 27, 2024

**Decision:** Doppel Center is developer-first. The API is the product. doppel.center frontend is a showcase/playground, not the core offering.

**Rationale:**
- **API as Product:** Primary value delivery is through programmatic access
- **Frontend as Demo:** doppel.center shows what's possible, facilitates testing
- **Embeddability:** Partners (Connie, DutyCall) consume via API, not by sending users to our site
- **Backend First:** Build and perfect API functionality before polishing frontend UX
- **Postman as Documentation:** API collection serves as both testing tool and integration guide

**Implications:**
- New features start as API endpoints, frontend follows
- Documentation is API-centric
- Success measured by API adoption, not website traffic
- Partners white-label the experience; we provide the engine

**Cross-Reference:** [DEC-001](#dec-001-platform-architecture) - Reinforces microservices philosophy

---

## DEC-013: Frontend/API Separation

**Date:** December 27, 2024

**Decision:** Deploy API and demo frontend as separate services on different hosts. API at doppel.center (Render), frontend at voice-demos.doppel.center (Vercel).

**Rationale:**
- **API Purity:** doppel.center serves only JSON—no static files, no HTML. Clean API-first architecture.
- **Independent Scaling:** Frontend is static files (CDN-friendly), API needs compute. Different hosting optimizes each.
- **Deployment Isolation:** Frontend changes don't require API redeployment and vice versa.
- **Render Limitation:** Render's root directory setting made serving sibling directories problematic. Rather than hack around it, we embraced the cleaner architecture.
- **Demo as Consumer:** The demo frontend is now just another API consumer, exactly like a partner integration would be.

**Implementation:**
- **API (Render):**
  - Root endpoint (`/`) returns JSON with API info and endpoint list
  - CORS configured for voice-demos.doppel.center
  - No static file serving
- **Frontend (Vercel):**
  - Pure static files (HTML, CSS, JS)
  - `API_BASE_URL` defaults to `https://doppel.center/api`
  - Vercel Authentication disabled for public access

**Hosting Details:**
| Component | Host | Account | URL |
|-----------|------|---------|-----|
| API | Render | chrisberno | https://doppel.center |
| Frontend | Vercel | chris-2413 | https://voice-demos.doppel.center |
| DNS | Spaceship | chrisberno | doppel.center |

**Cross-Reference:** [DEC-012](#dec-012-developer-first-model) - Frontend separation reinforces API-first model

---

## Pending Decisions

*Decisions identified but not yet resolved:*

| Topic | Context | Blocking? |
|-------|---------|-----------|
| Exact trial limits | Time vs. usage vs. hybrid | No—MVP can launch with TBD |
| Prepay vs. postpay for House Account | Credit risk management | No—deferred until metering implemented |
| SOC2 / HIPAA timeline | Enterprise requirement | No—can proceed without initially |
| International localization | Non-English markets | No—English-first MVP |
| Rate limiting strategy | House Account abuse prevention | No—monitor usage first |

---

## Cross-References

- **Business model details:** [BUSINESS-MODEL.md](./BUSINESS-MODEL.md)
- **Strategic product vision:** [STRATEGIC-VISION.md](./STRATEGIC-VISION.md)

---

*This is a living document. Decisions should be logged as they are made.*
