# Doppel Center Business Model

*Last Updated: December 27, 2024*

---

## Executive Summary

Doppel Center (doppel.center) is a **provider-agnostic voice talent gallery and configuration tool** purpose-built for IVR and contact center applications. We solve a universal pain point: finding and configuring the right synthetic voice is tedious, fragmented, and time-consuming.

Our platform enables businesses to audition, configure, and deploy synthetic voices across multiple TTS providers through a single, elegant interface. Whether embedded in enterprise telephony platforms or accessed directly by small business owners, Doppel Center delivers the **perfect voice in 2 minutes, not 2 hours**.

**Ownership:** chrisberno.dev
**Primary Integration Targets:** connie.plus, dutycall.app, and third-party IVR/CCaaS platforms

---

## Platform Architecture

### Core Design Principles

- **API-First:** Every capability exposed via REST API
- **Microservices Model:** Doppel does ONE thing exceptionally well—voice/TTS management
- **Embeddable:** Deployable via iframe or direct API integration
- **Provider-Agnostic:** Abstract the complexity of multiple TTS providers behind a unified interface

### Integration Model

Consuming applications (B2B partners) handle their own user authentication. They call Doppel Center with their API key, and Doppel handles all voice-related operations. This clean separation ensures:

- Partners maintain full control of their user experience
- Doppel remains a focused, composable microservice
- Integration complexity stays minimal

---

## Customer Segments

### B2B: Platform Integrators

**Profile:** Businesses embedding Doppel into their own products (Connie, DutyCall, third-party CCaaS platforms)

**Characteristics:**
- Typically have existing TTS provider accounts (Twilio, ElevenLabs, etc.)
- Need voice selection/configuration as a feature within their platform
- Value API reliability, documentation, and white-label capability
- Pay platform fees; manage their own provider relationships

**Use Case Example:** DutyCall embeds the Doppel voice gallery in their IVR builder, letting their customers audition and select voices without leaving the DutyCall interface.

### B2C: Direct Users

**Profile:** Small business owners, solo operators, the "nephew scenario"

**Characteristics:**
- Do NOT have Twilio accounts or provider relationships
- Expect a single bill from a single vendor
- Need simplicity over configurability
- Willing to pay markup for convenience

**Use Case Example:** A dental office manager wants a professional voice for their after-hours IVR. They don't know what "Twilio" is and don't want to. They want to pick a voice, hear it, and pay one invoice.

---

## Credential Model (Three-Tier)

Our credential architecture serves the full spectrum of users, from developers testing in sandboxes to enterprises with strict security requirements.

### Tier 1: Pass-Through

**Mechanism:** Credentials included in API request payload

**Use Cases:**
- Development and testing
- One-off integrations
- Environments where credential storage isn't desired

**Trade-offs:** Maximum flexibility, minimum convenience for production use

### Tier 2: BYOK (Bring Your Own Keys)

**Mechanism:** Customer's provider credentials stored encrypted within Doppel

**Use Cases:**
- B2B integrators with existing provider accounts
- Production environments requiring credential persistence
- Customers who want their own provider billing relationship

**Trade-offs:** Customer pays provider directly; pays Doppel platform fee separately

### Tier 3: House Account

**Mechanism:** No credentials provided → Doppel uses master provider credentials → bills customer with markup

**Use Cases:**
- B2C direct users (the "nephew scenario")
- Customers who want single-vendor simplicity
- Quick-start onboarding without provider setup
- **Current Priority:** Primary development focus as of Dec 27, 2024

**Trade-offs:** Higher per-unit cost; maximum convenience

**Implementation Status (Dec 27, 2024):**
- AWS credentials configured server-side in Render environment
- `/api/generate` being modified to accept requests without credentials
- No metering or billing infrastructure yet—build value first
- doppel.center frontend serves as testing ground

---

## Revenue Model

### B2B Revenue (BYOK Model)

| Revenue Stream | Description |
|----------------|-------------|
| Platform Fee | Subscription or usage-based fee for API access |
| Overage Charges | Usage beyond plan limits |
| Premium Features | Advanced capabilities (Voice Casting AI, priority support) |

**Customer pays:** Their TTS provider directly for synthesis costs; Doppel for platform value

### B2C Revenue (House Account Model)

| Revenue Stream | Description |
|----------------|-------------|
| Usage + Markup | TTS costs passed through with margin |
| Platform Fee | May be bundled into usage pricing |

**Customer pays:** Single invoice from Doppel covering everything

### Philosophy: "Tool, Not Telco"

We enable voice selection and configuration. We do not position ourselves as a telecom reseller. The House Account model exists purely for B2C simplicity—it's a convenience offering, not a core business strategy.

---

## Pricing Philosophy

### Core Principles

1. **NOT Free:** If it provides value, it deserves compensation
2. **NOT Freemium:** No artificial feature walls designed to frustrate users into upgrading
3. **Generous Trial/Sandbox:** Ample room for testing, learning, and validating the product fits their needs
4. **Value-Based:** Price reflects the time and frustration we eliminate

### Pricing Models Under Consideration

- **Pay-Per-Use:** Charged per synthesis request or character
- **Bundles:** Pre-purchased usage at volume discounts
- **Platform Subscription:** Monthly/annual fee with usage allowances

### Guiding Question

*"If it's valuable enough to use in production, it's valuable enough to pay for."*

---

## Provider Strategy

### Priority Roadmap

| Priority | Provider | Rationale |
|----------|----------|-----------|
| **1** | Twilio (Polly) | MVP foundation, immediate IVR value, established enterprise trust |
| **2** | Doppel Clone (VoiceCraft) | Core differentiator, voice cloning capability, early integration even in beta |
| **3** | ElevenLabs | Premium prefab voice expansion, high-quality synthesis |
| **4** | Hume | Emotional TTS, differentiated capability |
| **5+** | Others | Demand-driven expansion |

### Integration Philosophy

- Lead with proven, enterprise-ready providers (Twilio)
- Differentiate with cutting-edge capability (VoiceCraft cloning)
- Expand based on customer demand, not feature checkbox thinking

---

## Competitive Moats

### 1. Voice Casting AI
JTBD-driven intelligent voice matching. Not just filters—understanding *why* a customer needs a voice and serving curated auditions.

### 2. Doppel Clone (VoiceCraft)
Proprietary voice cloning integration. Your brand's voice, synthesized on demand.

### 3. Time-to-Value
Perfect voice in 2 minutes, not 2 hours of scrolling through provider consoles.

### 4. Data Moat
Every voice selection trains our recommendation engine. Usage patterns become institutional knowledge that competitors cannot replicate.

### 5. UX Moat
Curated recommendations vs. endless dropdown lists. We make decisions easier, not just possible.

---

## Future Vision

### Audio Storage Evolution

**Phase 1 (MVP):** On-demand only
- Generate audio, return to caller, discard
- Zero storage complexity
- Validates core value proposition

**Future State:** Script Management System
- Saved scripts with version history
- Voice associations per script
- One-click regeneration when voices update
- Audit trail for compliance-sensitive industries

### Voice Casting AI

**Phase 1:** Pull voice metadata from provider APIs

**Future State:** Intelligent JTBD matching
- "I need a [demographic] voice that [characteristic] so I can [outcome]"
- AI serves 3 curated auditions
- User fine-tunes with natural language
- Every selection improves the model

### Platform Evolution

See [STRATEGIC-VISION.md](./STRATEGIC-VISION.md) for the three-phase product roadmap.

---

## Cross-References

- **Strategic product vision:** [STRATEGIC-VISION.md](./STRATEGIC-VISION.md)
- **Decision rationale and history:** [DECISIONS-LOG.md](./DECISIONS-LOG.md)

---

## Current Status (December 27, 2024)

### Production Infrastructure

| Component | Status | Details |
|-----------|--------|---------|
| API Server | Live | doppel.center (Render.com) |
| Domain | Configured | doppel.center via Spaceship DNS |
| SSL | Active | Let's Encrypt auto-provisioned |
| GitHub | Connected | chrisberno/doppel-center, auto-deploy on push |
| AWS Credentials | Configured | Environment variables in Render |

### First Integration

**Connie (connie.one)** serves as the first integration customer:
- `/voice-interface` page displays all 16 voices
- Fetches from doppel.center/api/voices
- Audio preview functionality working
- Deployed via AWS Amplify

### Immediate Roadmap

1. **House Account TTS Generation** - In progress
   - Allow TTS without requiring credentials
   - Use server-side AWS Polly credentials
   - No metering yet—build value first

2. **Postman Collection Updates** - Pending
   - Add house account TTS tests
   - Document new credential-optional flow

3. **Frontend TTS Interface** - Future
   - After API is validated, add UI to doppel.center

---

*This is a living document. Last substantive update: December 27, 2024*
