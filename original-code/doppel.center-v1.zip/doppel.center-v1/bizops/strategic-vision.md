# Doppel Center Strategic Vision

*Last Updated: December 27, 2024*

---

## Vision Statement

**Doppel Center is the Voice Talent Agency for IVR.**

Just as casting directors curate talent for productions, we curate synthetic voices for business communications. We're not a TTS provider—we're the intelligent layer that helps businesses find, configure, and deploy the perfect voice across any provider.

The voice your customers hear shapes their perception of your brand. That choice shouldn't require a PhD in AI or hours scrolling through provider consoles.

---

## Product Evolution

### Phase 1: Voice Gallery (MVP)

**Core Offering:** Provider-agnostic voice discovery and configuration

**Status:** IN PRODUCTION as of December 27, 2024

**Capabilities:**
- Unified interface across multiple TTS providers
- Voice audition with custom text
- SSML configuration and preview
- API-first architecture for embedding
- Three-tier credential model (pass-through, BYOK, house account)

**Value Proposition:** "Find the right voice in 2 minutes, not 2 hours"

**Success Metrics:**
- Time from landing to voice selection
- Integration adoption by target platforms
- Voice audition volume

**December 2024 Progress:**
- API deployed to production at doppel.center (Render.com)
- 16 curated voices across 4 languages (AWS Polly via Twilio)
- Voice preview with pre-baked audio samples
- First integration: connie.one/voice-interface
- Postman collection for API testing/documentation
- CORS configured for connie.one, connie.plus, dutycall.app

**Current Focus (Dec 27):**
- Implementing House Account TTS generation (no credentials required)
- Backend-first development: API functionality before frontend polish
- doppel.center serves as "lab rat" for feature testing

---

### Phase 2: Doppel Clone

**Core Offering:** Voice cloning integration via VoiceCraft

**Capabilities:**
- Custom voice creation from audio samples
- Brand voice synthesis (use YOUR spokesperson, YOUR CEO)
- Clone management and versioning
- Seamless integration with gallery experience

**Value Proposition:** "Your brand's voice, on demand"

**Success Metrics:**
- Clone creation volume
- Clone usage vs. prefab ratio
- Enterprise adoption rate

**Strategic Note:** Early integration priority even in beta—this is a core differentiator, not a feature add-on.

---

### Phase 3: Voice Production Studio

**Core Offering:** Full script-to-audio production workflow

**Capabilities:**
- Script Management System (saved scripts, version history, voice associations)
- One-click regeneration across voice updates
- Multi-voice scene composition
- Collaboration tools for teams
- Compliance audit trails

**Value Proposition:** "Your complete voice production toolkit"

**Success Metrics:**
- Script library size per customer
- Regeneration frequency
- Team collaboration usage

---

## Moat Analysis

### Defensible Advantages

| Moat | Description | Defensibility |
|------|-------------|---------------|
| **Voice Casting AI** | JTBD-driven intelligent matching | High—requires usage data + ML investment |
| **Doppel Clone** | VoiceCraft integration | Medium—partnership dependent, but early mover |
| **Time-to-Value** | Optimized UX for rapid selection | Medium—replicable but requires focus |
| **Data Moat** | Selection patterns train recommendations | High—grows with usage, compounds over time |
| **UX Moat** | Curated vs. overwhelming | Medium—requires sustained design investment |

### Moat Flywheel

```
More Users → More Selections → Better Recommendations → Faster Time-to-Value → More Users
```

Every voice selection is a training signal. Competitors starting today are starting with zero data. We build institutional knowledge with every use.

---

## Key Innovations

### Voice Casting AI

**The Problem:** Existing voice selection is filter-based—provider, gender, language, accent. These are *attributes*, not *outcomes*.

**Our Approach:** Jobs-to-Be-Done (JTBD) driven matching

**User Input Pattern:**
> "I need a **[demographic/style]** voice that **[characteristic/behavior]** so I can **[desired outcome]**"

**Examples:**
- "I need a *warm, mature* voice that *sounds trustworthy* so I can *reassure callers during hold times*"
- "I need a *young, energetic* voice that *speaks quickly* so I can *appeal to our Gen-Z customer base*"
- "I need a *neutral, professional* voice that *sounds authoritative* so I can *deliver compliance disclosures*"

**AI Response:** 3 curated auditions, ranked by fit

**Refinement Loop:** User feedback ("more formal," "younger," "slower") refines in real-time

**Data Capture:** Every selection trains the model on what "trustworthy" or "energetic" actually means in context

---

### Script Management System (Future)

**The Problem:** Voice production is currently ephemeral—generate, use, forget. No institutional memory of what was said, with what voice, when.

**Our Solution:** Persistent script infrastructure

**Capabilities:**
- Script library with search and organization
- Voice associations (Script X always uses Voice Y)
- Version history with diff view
- One-click regeneration when voices update or improve
- Compliance-ready audit trail

**Use Case:** Insurance company needs to update disclosures quarterly. Instead of re-creating from scratch, they pull up the script, review the voice association, regenerate, and deploy—minutes, not hours.

---

## Platform Philosophy

### Tool, Not Telco

We are a **tool** that enables voice selection and configuration. We are not a telecommunications company or a TTS provider ourselves.

**Implications:**
- We don't compete with our provider partners
- We add value through UX, intelligence, and integration—not markup arbitrage
- House Account model is a convenience feature for B2C simplicity, not a revenue strategy

### Microservice Mindset

Doppel does ONE thing: voice/TTS management. We do it exceptionally well.

**We Do:**
- Voice discovery and audition
- SSML configuration
- Credential management
- Provider abstraction
- Voice recommendation

**We Don't:**
- User authentication (consuming apps handle this)
- Telephony routing
- Call center operations
- General-purpose audio editing

### Embeddability as Core Value

Doppel should feel native wherever it appears—in Connie, in DutyCall, in third-party platforms. Our success is measured by how seamlessly we disappear into our partners' experiences while elevating their capability.

---

## Strategic Clarity (December 27, 2024)

### Product Identity

**Doppel Center is a developer-first API product.** The doppel.center website is a showcase and playground—a way to demonstrate capabilities and facilitate testing—but the API is the product.

- Partners (Connie, DutyCall, future integrators) consume via API
- They white-label the experience in their own applications
- We provide the engine; they provide the interface
- Success is measured by API adoption, not website traffic

### Development Philosophy

**Backend first, frontend follows.** New features start as API endpoints, validated via Postman, then surfaced in the doppel.center frontend.

**doppel.center as lab rat.** The retail frontend is our testing ground. Build and perfect features there before rolling out to partner integrations.

**Build value first, meter later.** No usage tracking or billing infrastructure until we've proven the feature delivers value worth paying for.

### Current Strategic Focus

1. **House Account TTS** - Enable text-to-speech generation without requiring credentials
2. **Connie Integration** - Use connie.one as first integration showcase
3. **API Documentation** - Postman collection as living documentation

---

## Open Questions (Future Resolution)

*These strategic questions remain open for future decision-making:*

1. **Marketplace Model:** Should Doppel evolve to include a marketplace where voice talent can list cloned voices for licensing?

2. **Enterprise vs. SMB Focus:** At what scale do we need dedicated enterprise sales motion vs. PLG growth?

3. **Provider Relationships:** As we grow, do we negotiate volume discounts with providers to improve house account economics?

4. **International Expansion:** What's the localization strategy for non-English markets?

5. **Compliance Certification:** Which industry certifications (HIPAA, SOC2, etc.) are table stakes vs. differentiators?

6. **Rate Limiting:** How do we prevent House Account abuse without adding friction?

---

## Cross-References

- **Business model details:** [BUSINESS-MODEL.md](./BUSINESS-MODEL.md)
- **Decision rationale and history:** [DECISIONS-LOG.md](./DECISIONS-LOG.md)

---

## Progress Timeline

| Date | Milestone |
|------|-----------|
| Dec 25, 2024 | MVP complete: 16 voices, API routes, frontend |
| Dec 27, 2024 | Production deployment to Render (doppel.center) |
| Dec 27, 2024 | First integration: connie.one/voice-interface |
| Dec 27, 2024 | Postman collection published |
| Dec 27, 2024 | House Account TTS implementation started |

---

*This is a living document. Last substantive update: December 27, 2024*
