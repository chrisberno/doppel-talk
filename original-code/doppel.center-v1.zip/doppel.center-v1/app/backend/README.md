# Doppel Center Backend

Backend API for Doppel Center - Voice Provider Management System.

> **Note**: For comprehensive API documentation including all endpoints, error codes, authentication, and detailed examples, see **[API.md](./API.md)**.

## Prerequisites

- Node.js 18.0.0 or higher
- npm

## Installation

```bash
cd backend
npm install
```

## Environment Setup

1. Copy the example environment file:
   ```bash
   cp ../.env.example .env
   ```

2. Edit `.env` and configure your settings:
   - `PORT` - Server port (default: 3000)
   - `NODE_ENV` - Environment mode (development/production)
   - `ALLOWED_ORIGINS` - Comma-separated CORS origins

## Running the Server

### Development (with auto-reload)
```bash
npm run dev
```

### Production
```bash
npm start
```

## API Endpoints

### Health Check

**GET /health**

Returns server health status.

```json
{
  "status": "ok"
}
```

### Voices

**GET /api/voices**

Get all voices with optional filtering.

Query Parameters:
| Parameter | Type | Description |
|-----------|------|-------------|
| `provider` | string | Filter by provider (e.g., `twilio`) |
| `gender` | string | Filter by gender (`male`, `female`) |
| `language` | string | Filter by language code (e.g., `en-US`, `es-MX`) |
| `accent` | string | Filter by accent (e.g., `american`, `british`) |
| `engine` | string | Filter by engine type (`neural`, `generative`) |
| `tags` | string | Comma-separated tags (e.g., `professional,warm`) |
| `search` | string | Text search across name and tags |

Example Request:
```bash
curl "http://localhost:3000/api/voices?gender=female&language=en-US"
```

Example Response:
```json
{
  "voices": [
    {
      "id": "joanna-en-us",
      "provider": "twilio",
      "providerVoiceId": "Polly.Joanna-Neural",
      "engine": "neural",
      "name": "Joanna",
      "gender": "female",
      "language": "en-US",
      "accent": "american",
      "tags": ["professional", "warm", "clear"],
      "previewText": "Hello, I'm Joanna...",
      "pricing": {
        "perCharacter": 0.000004,
        "currency": "USD"
      }
    }
  ],
  "meta": {
    "total": 1,
    "filters": {
      "gender": "female",
      "language": "en-US"
    }
  }
}
```

**GET /api/voices/:id**

Get a single voice by ID.

Example Request:
```bash
curl "http://localhost:3000/api/voices/joanna-en-us"
```

Example Response:
```json
{
  "id": "joanna-en-us",
  "provider": "twilio",
  "providerVoiceId": "Polly.Joanna-Neural",
  "engine": "neural",
  "name": "Joanna",
  "gender": "female",
  "language": "en-US",
  "accent": "american",
  "tags": ["professional", "warm", "clear"],
  "previewText": "Hello, I'm Joanna...",
  "pricing": {
    "perCharacter": 0.000004,
    "currency": "USD"
  }
}
```

Returns 404 if voice not found:
```json
{
  "error": "Not Found",
  "message": "Voice with ID 'unknown-voice' not found"
}
```

### Providers

**GET /api/providers**

Get list of configured voice providers.

Example Response:
```json
{
  "providers": [
    {
      "id": "twilio",
      "name": "Twilio (Amazon Polly)",
      "description": "High-quality neural and generative voices...",
      "engines": ["neural", "generative"],
      "status": "active"
    }
  ],
  "meta": {
    "total": 1
  }
}
```

## Voice Data Structure

Each voice object contains:

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Unique voice identifier |
| `provider` | string | Provider name (e.g., `twilio`) |
| `providerVoiceId` | string | Provider's internal voice ID |
| `engine` | string | Voice engine (`neural`, `generative`) |
| `name` | string | Human-readable voice name |
| `gender` | string | Voice gender (`male`, `female`) |
| `language` | string | Language code (e.g., `en-US`) |
| `accent` | string | Accent type |
| `tags` | array | Descriptive tags |
| `previewText` | string | Sample text for voice preview |
| `pricing` | object | Pricing information |

## Available Voices (MVP)

The current voice catalog includes 16 curated Twilio/Polly voices:

| Language | Voices |
|----------|--------|
| English (US) | Joanna, Matthew, Ruth, Stephen, Danielle, Gregory |
| English (GB) | Amy, Brian, Emma |
| Spanish (US) | Lupe, Pedro |
| Spanish (MX) | Mia |
| Portuguese (BR) | Camila, Thiago |
| French (FR) | Lea, Remi |

## Future Expansion

The architecture supports adding additional providers:

- **Phase 2**: Twilio TTS generation (audio synthesis)
- **Phase 3**: ElevenLabs integration
- **Phase 3**: Hume AI integration

Provider stubs are located in `services/providers/`.
