# Doppel Center API Reference

> Comprehensive API documentation for the Doppel Center voice provider management system.

## Overview

The Doppel Center API provides endpoints for browsing voice catalogs, generating text-to-speech audio, and exporting voice configurations for various Twilio integration formats.

### Base URL

```
http://localhost:3000
```

### Authentication Model

Doppel Center uses a **pass-through credentials** model. Credentials are not stored on the server; instead, they are sent with each request that requires provider access. This approach:

- Keeps credentials under user control
- Eliminates credential storage security concerns
- Allows users to switch between accounts seamlessly

### Rate Limiting

The API does not currently implement rate limiting. However, provider APIs (Twilio, AWS Polly) have their own rate limits:

- **Twilio API**: Varies by account type
- **AWS Polly**: 8 concurrent requests, 80 requests/second

---

## Common Response Formats

### Success Response

Success response shapes vary by endpoint. See individual endpoint documentation for specific response formats.

### Error Response

All error responses follow a consistent format:

```json
{
  "error": "Human-readable error message",
  "code": "MACHINE_READABLE_CODE"
}
```

Some endpoints may also include a `message` field with additional details.

---

## Error Codes Reference

| HTTP Status | Error Code | Description | Resolution |
|-------------|------------|-------------|------------|
| 400 | `BAD_REQUEST` | Invalid request parameters | Check request format and required fields |
| 400 | `MISSING_VOICE_ID` | voiceId field required | Include voiceId in request body |
| 400 | `INVALID_VOICE_ID` | voiceId must be a non-empty string | Provide a valid voice ID string |
| 400 | `MISSING_TEXT` | text field required | Include text in request body |
| 400 | `TEXT_TOO_LONG` | Text exceeds 3000 characters | Reduce text length to ≤3000 characters |
| 400 | `INVALID_FORMAT` | Export format not supported | Use twiml, studio, or api |
| 401 | `UNAUTHORIZED` | Missing or invalid credentials | Provide valid Twilio credentials |
| 401 | `MISSING_CREDENTIALS` | credentials field required | Include credentials object in request |
| 401 | `INVALID_CREDENTIALS_FORMAT` | Malformed credentials object | Ensure accountSid and authToken are provided |
| 401 | `INVALID_ACCOUNT_SID` | Invalid Account SID format | Must start with "AC" and be 34 characters |
| 401 | `INVALID_AUTH_TOKEN` | Invalid Auth Token format | Must be exactly 32 characters |
| 404 | `NOT_FOUND` | Resource not found | Check voice ID or endpoint path |
| 501 | `NOT_IMPLEMENTED` | Provider not yet supported | Use a supported provider (twilio) |
| 502 | `PROVIDER_ERROR` | External provider error | Check provider status, retry later |
| 500 | `INTERNAL_ERROR` | Server error | Contact support if issue persists |

---

## Endpoints

### Health Check

#### `GET /health`

Returns server health status. Use this endpoint for deployment health checks and monitoring.

**Response**

```json
{
  "status": "ok"
}
```

**Example: curl**

```bash
curl http://localhost:3000/health
```

**Example: JavaScript**

```javascript
const response = await fetch('http://localhost:3000/health');
const data = await response.json();
console.log(data.status); // "ok"
```

---

### Get All Voices

#### `GET /api/voices`

Retrieves all available voices with optional filtering.

**Query Parameters**

| Parameter | Type | Description | Example |
|-----------|------|-------------|---------|
| `provider` | string | Filter by provider | `twilio` |
| `gender` | string | Filter by gender | `male`, `female` |
| `language` | string | Filter by language code | `en-US`, `es-MX` |
| `accent` | string | Filter by accent | `american`, `british`, `brazilian` |
| `engine` | string | Filter by engine type | `neural`, `generative` |
| `tags` | string | Comma-separated tags (matches ANY) | `professional,warm` |
| `search` | string | Text search across name and tags | `joanna` |

**Response**

```json
{
  "voices": [
    {
      "id": "joanna-en-us",
      "provider": "twilio",
      "providerVoiceId": "Polly.Joanna-Neural",
      "engine": "neural",
      "name": "Joanna",
      "gender": "female",
      "language": "en-US",
      "accent": "american",
      "tags": ["professional", "warm", "clear"],
      "previewText": "Hello, I'm Joanna...",
      "pricing": {
        "perCharacter": 0.000004,
        "currency": "USD"
      }
    }
  ],
  "meta": {
    "total": 16,
    "filters": {
      "gender": "female"
    }
  }
}
```

**Example: curl**

```bash
# Get all voices
curl "http://localhost:3000/api/voices"

# Filter by gender and language
curl "http://localhost:3000/api/voices?gender=female&language=en-US"

# Search by name
curl "http://localhost:3000/api/voices?search=joanna"
```

**Example: JavaScript**

```javascript
const params = new URLSearchParams({
  gender: 'female',
  language: 'en-US'
});

const response = await fetch(`http://localhost:3000/api/voices?${params}`);
const { voices, meta } = await response.json();
console.log(`Found ${meta.total} voices`);
```

---

### Get Voice by ID

#### `GET /api/voices/:id`

Retrieves a single voice by its unique identifier.

**Path Parameters**

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | string | Unique voice identifier |

**Success Response (200)**

```json
{
  "id": "joanna-en-us",
  "provider": "twilio",
  "providerVoiceId": "Polly.Joanna-Neural",
  "engine": "neural",
  "name": "Joanna",
  "gender": "female",
  "language": "en-US",
  "accent": "american",
  "tags": ["professional", "warm", "clear"],
  "previewText": "Hello, I'm Joanna...",
  "pricing": {
    "perCharacter": 0.000004,
    "currency": "USD"
  }
}
```

**Error Response (404)**

```json
{
  "error": "Not Found",
  "code": "NOT_FOUND",
  "message": "Voice with ID 'unknown-voice' not found"
}
```

**Example: curl**

```bash
curl "http://localhost:3000/api/voices/joanna-en-us"
```

**Example: JavaScript**

```javascript
const voiceId = 'joanna-en-us';
const response = await fetch(`http://localhost:3000/api/voices/${voiceId}`);

if (!response.ok) {
  const error = await response.json();
  console.error(error.message);
} else {
  const voice = await response.json();
  console.log(voice.name); // "Joanna"
}
```

---

### Get Providers

#### `GET /api/providers`

Retrieves the list of configured voice providers.

**Response**

```json
{
  "providers": [
    {
      "id": "twilio",
      "name": "Twilio (Amazon Polly)",
      "description": "High-quality neural and generative voices via Twilio's Amazon Polly integration",
      "engines": ["neural", "generative"],
      "status": "active"
    }
  ],
  "meta": {
    "total": 1
  }
}
```

**Example: curl**

```bash
curl "http://localhost:3000/api/providers"
```

**Example: JavaScript**

```javascript
const response = await fetch('http://localhost:3000/api/providers');
const { providers } = await response.json();

providers.forEach(provider => {
  console.log(`${provider.name}: ${provider.status}`);
});
```

---

### Generate Speech

#### `POST /api/generate`

Generates audio from text using the specified voice. Requires Twilio credentials.

**Request Body**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `voiceId` | string | Yes | Voice ID from the voices registry |
| `text` | string | Yes | Text to convert to speech (max 3000 chars) |
| `credentials` | object | Yes | Twilio credentials object |
| `credentials.accountSid` | string | Yes | Twilio Account SID (starts with "AC", 34 chars) |
| `credentials.authToken` | string | Yes | Twilio Auth Token (32 chars) |

**Validation Rules**

- `voiceId`: Must match an existing voice in the registry
- `text`: Must be 1-3000 characters
- `credentials.accountSid`: Must start with "AC" and be exactly 34 characters
- `credentials.authToken`: Must be exactly 32 characters

**Success Response (200)**

```json
{
  "audio": "//uQxAAAAAANIAAAAAExBTUUzLjEwMFVV...",
  "format": "mp3",
  "voiceId": "joanna-en-us",
  "textLength": 150
}
```

The `audio` field contains base64-encoded MP3 audio data.

**Error Responses**

| Status | Code | Cause |
|--------|------|-------|
| 400 | `MISSING_VOICE_ID` | voiceId not provided |
| 400 | `MISSING_TEXT` | text not provided |
| 400 | `TEXT_TOO_LONG` | text exceeds 3000 characters |
| 401 | `MISSING_CREDENTIALS` | credentials not provided |
| 401 | `INVALID_CREDENTIALS_FORMAT` | credentials missing accountSid or authToken |
| 401 | `INVALID_ACCOUNT_SID` | accountSid format invalid |
| 401 | `INVALID_AUTH_TOKEN` | authToken format invalid |
| 401 | `UNAUTHORIZED` | credentials rejected by Twilio |
| 404 | `NOT_FOUND` | voiceId not found in registry |
| 502 | `PROVIDER_ERROR` | TTS generation failed at provider |

**Example: curl**

```bash
curl -X POST "http://localhost:3000/api/generate" \
  -H "Content-Type: application/json" \
  -d '{
    "voiceId": "joanna-en-us",
    "text": "Hello, this is a test message.",
    "credentials": {
      "accountSid": "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
      "authToken": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    }
  }'
```

**Example: JavaScript**

```javascript
const response = await fetch('http://localhost:3000/api/generate', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    voiceId: 'joanna-en-us',
    text: 'Hello, this is a test message.',
    credentials: {
      accountSid: 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
      authToken: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    }
  })
});

if (!response.ok) {
  const error = await response.json();
  console.error(`${error.code}: ${error.error}`);
} else {
  const { audio, format } = await response.json();

  // Convert base64 to blob for playback
  const audioBlob = base64ToBlob(audio, 'audio/mpeg');
  const audioUrl = URL.createObjectURL(audioBlob);

  const audioElement = new Audio(audioUrl);
  audioElement.play();
}

function base64ToBlob(base64, mimeType) {
  const byteCharacters = atob(base64);
  const byteNumbers = new Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  return new Blob([new Uint8Array(byteNumbers)], { type: mimeType });
}
```

**Notes**

- Audio generation requires valid Twilio credentials AND AWS credentials configured on the server
- AWS credentials are set via environment variables: `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`
- The API uses Twilio credentials to authenticate the user, then AWS Polly for actual TTS generation

---

### Validate Credentials

#### `POST /api/validate-credentials`

Validates provider credentials without generating audio. Useful for checking credentials before audio generation.

**Request Body**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `provider` | string | No | Provider name (default: "twilio") |
| `credentials` | object | Yes | Provider credentials object |
| `credentials.accountSid` | string | Yes | Twilio Account SID |
| `credentials.authToken` | string | Yes | Twilio Auth Token |

**Success Response (200)**

```json
{
  "valid": true
}
```

```json
{
  "valid": false
}
```

**Error Responses**

| Status | Code | Cause |
|--------|------|-------|
| 400 | `INVALID_CREDENTIALS_FORMAT` | Missing accountSid or authToken |
| 501 | `NOT_IMPLEMENTED` | Provider not supported |

**Example: curl**

```bash
curl -X POST "http://localhost:3000/api/validate-credentials" \
  -H "Content-Type: application/json" \
  -d '{
    "credentials": {
      "accountSid": "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
      "authToken": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    }
  }'
```

**Example: JavaScript**

```javascript
async function validateCredentials(accountSid, authToken) {
  const response = await fetch('http://localhost:3000/api/validate-credentials', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      credentials: { accountSid, authToken }
    })
  });

  const { valid } = await response.json();
  return valid;
}

const isValid = await validateCredentials('AC...', 'xxx...');
console.log(isValid ? 'Credentials valid' : 'Credentials invalid');
```

---

### Export Configuration

#### `POST /api/export/:format`

Generates export configuration for a voice in various Twilio integration formats.

**Path Parameters**

| Parameter | Type | Description |
|-----------|------|-------------|
| `format` | string | Export format: `twiml`, `studio`, or `api` |

**Request Body**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `voiceId` | string | Yes | Voice ID from the voices registry |

**Export Formats**

| Format | Description | Use Case |
|--------|-------------|----------|
| `twiml` | TwiML XML snippet | Direct TwiML responses, `<Say>` verbs |
| `studio` | Twilio Studio JSON | Studio flow "Say/Play" widget configuration |
| `api` | JavaScript/Node.js code | Programmatic TTS via Twilio SDK |

**Success Response (200)**

```json
{
  "format": "twiml",
  "config": "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<Response>\n  <Say voice=\"Polly.Joanna-Neural\">Your message here</Say>\n</Response>"
}
```

**Error Responses**

| Status | Code | Cause |
|--------|------|-------|
| 400 | `MISSING_VOICE_ID` | voiceId not provided |
| 400 | `INVALID_VOICE_ID` | voiceId is not a valid string |
| 400 | `INVALID_FORMAT` | format is not twiml, studio, or api |
| 404 | `NOT_FOUND` | voiceId not found in registry |

**Example: curl**

```bash
# Get TwiML configuration
curl -X POST "http://localhost:3000/api/export/twiml" \
  -H "Content-Type: application/json" \
  -d '{"voiceId": "joanna-en-us"}'

# Get Studio JSON configuration
curl -X POST "http://localhost:3000/api/export/studio" \
  -H "Content-Type: application/json" \
  -d '{"voiceId": "joanna-en-us"}'

# Get API code snippet
curl -X POST "http://localhost:3000/api/export/api" \
  -H "Content-Type: application/json" \
  -d '{"voiceId": "joanna-en-us"}'
```

**Example: JavaScript**

```javascript
async function getExportConfig(voiceId, format) {
  const response = await fetch(`http://localhost:3000/api/export/${format}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ voiceId })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error);
  }

  const { config } = await response.json();
  return config;
}

// Get TwiML for Joanna voice
const twiml = await getExportConfig('joanna-en-us', 'twiml');
console.log(twiml);
```

**Sample Output: TwiML**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Joanna-Neural">Your message here</Say>
</Response>
```

**Sample Output: Studio JSON**

```json
{
  "type": "say-play",
  "properties": {
    "say": "Your message here",
    "voice": "Polly.Joanna-Neural",
    "language": "en-US"
  }
}
```

**Sample Output: API Code**

```javascript
const twilio = require('twilio');
const VoiceResponse = twilio.twiml.VoiceResponse;

const response = new VoiceResponse();
response.say({
  voice: 'Polly.Joanna-Neural'
}, 'Your message here');

console.log(response.toString());
```

---

## Voice Data Structure

Each voice object in the registry contains the following fields:

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Unique voice identifier (e.g., `joanna-en-us`) |
| `provider` | string | Provider name (e.g., `twilio`) |
| `providerVoiceId` | string | Provider's internal voice ID (e.g., `Polly.Joanna-Neural`) |
| `engine` | string | Voice engine type (`neural` or `generative`) |
| `name` | string | Human-readable voice name |
| `gender` | string | Voice gender (`male` or `female`) |
| `language` | string | Language code (e.g., `en-US`) |
| `accent` | string | Accent type (e.g., `american`, `british`) |
| `tags` | array | Descriptive tags for the voice |
| `previewText` | string | Sample text for voice previews |
| `pricing` | object | Pricing information |
| `pricing.perCharacter` | number | Cost per character in USD |
| `pricing.currency` | string | Currency code (always `USD`) |

---

## Available Voices

The current catalog includes 16 curated Twilio/Amazon Polly voices:

### English (US)

| Name | Engine | Gender | ID |
|------|--------|--------|-----|
| Joanna | Neural | Female | `joanna-en-us` |
| Matthew | Neural | Male | `matthew-en-us` |
| Ruth | Generative | Female | `ruth-en-us` |
| Stephen | Generative | Male | `stephen-en-us` |
| Danielle | Generative | Female | `danielle-en-us` |
| Gregory | Generative | Male | `gregory-en-us` |

### English (GB)

| Name | Engine | Gender | ID |
|------|--------|--------|-----|
| Amy | Neural | Female | `amy-en-gb` |
| Brian | Neural | Male | `brian-en-gb` |
| Emma | Neural | Female | `emma-en-gb` |

### Spanish (US)

| Name | Engine | Gender | ID |
|------|--------|--------|-----|
| Lupe | Neural | Female | `lupe-es-us` |
| Pedro | Neural | Male | `pedro-es-us` |

### Spanish (MX)

| Name | Engine | Gender | ID |
|------|--------|--------|-----|
| Mia | Neural | Female | `mia-es-mx` |

### Portuguese (BR)

| Name | Engine | Gender | ID |
|------|--------|--------|-----|
| Camila | Neural | Female | `camila-pt-br` |
| Thiago | Neural | Male | `thiago-pt-br` |

### French (FR)

| Name | Engine | Gender | ID |
|------|--------|--------|-----|
| Lea | Neural | Female | `lea-fr-fr` |
| Remi | Neural | Male | `remi-fr-fr` |

---

## Credential Requirements

### Twilio Credentials

Required for audio generation and credential validation:

- **Account SID**: Found in the Twilio Console dashboard
  - Format: Starts with `AC`, exactly 34 characters
  - Example: `ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

- **Auth Token**: Found in the Twilio Console dashboard
  - Format: Exactly 32 characters
  - Example: `xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

Get your credentials at: https://console.twilio.com

### AWS Credentials (Server-side)

Required on the server for actual TTS generation via Amazon Polly:

- `AWS_ACCESS_KEY_ID`: AWS access key
- `AWS_SECRET_ACCESS_KEY`: AWS secret key
- `AWS_REGION`: AWS region (default: `us-east-1`)

These are set as environment variables on the server and are not passed by the client.

---

## CORS Configuration

The API supports cross-origin requests from configured origins:

- **Development**: All origins allowed when `NODE_ENV=development`
- **Production**: Only origins listed in `ALLOWED_ORIGINS` environment variable

Configure allowed origins as a comma-separated list:

```bash
ALLOWED_ORIGINS=https://app.example.com,https://staging.example.com
```
