require('dotenv').config();

const express = require('express');
const path = require('path');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const voiceRoutes = require('./routes/voices');
const generateRoutes = require('./routes/generate');
const exportRoutes = require('./routes/export');

const app = express();
const PORT = process.env.PORT || 3000;

// Rate limiting for TTS generation (protects AWS bill)
// 20 requests per IP per 15 minutes for /api/generate
const generateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20, // 20 requests per window
  message: {
    error: 'Too many TTS requests. Please try again in a few minutes.',
    code: 'RATE_LIMIT_EXCEEDED'
  },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    // Use X-Forwarded-For for proxied requests (Render), fallback to IP
    return req.headers['x-forwarded-for']?.split(',')[0] || req.ip;
  }
});

// CORS configuration
const allowedOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(',')
  : [];

// Default allowed origins for production
const defaultOrigins = [
  'https://doppel.center',
  'https://www.doppel.center',
  'https://voice-demos.doppel.center',
  'https://connie.one',
  'https://connie.plus',
  'https://dutycall.app',
  'http://localhost:8080',
  'http://localhost:3000'
];

const allAllowedOrigins = [...new Set([...allowedOrigins, ...defaultOrigins])];

app.use(cors({
  origin: function (origin, callback) {
    // Allow requests with no origin (like mobile apps, curl, or same-origin requests)
    if (!origin) return callback(null, true);

    if (allAllowedOrigins.indexOf(origin) !== -1 || process.env.NODE_ENV === 'development') {
      callback(null, true);
    } else {
      console.log('CORS blocked origin:', origin);
      callback(new Error('Not allowed by CORS'));
    }
  }
}));

// Parse JSON request bodies
app.use(express.json());

// Serve static files from frontend assets (audio samples, etc.)
const frontendAssetsPath = path.join(__dirname, '../frontend/assets');
app.use('/assets', express.static(frontendAssetsPath, {
  maxAge: '1d', // Cache for 1 day
  setHeaders: (res, filePath) => {
    // Set proper MIME type for audio files
    if (filePath.endsWith('.mp3')) {
      res.setHeader('Content-Type', 'audio/mpeg');
    }
  }
}));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Mount API routes
app.use('/api', voiceRoutes);
app.use('/api/generate', generateLimiter); // Rate limit TTS generation
app.use('/api', generateRoutes);
app.use('/api', exportRoutes);

// Root route - API info
app.get('/', (req, res) => {
  res.json({
    name: 'Doppel Center API',
    version: '1.0.0',
    docs: 'https://voice-demos.doppel.center',
    endpoints: {
      health: '/health',
      voices: '/api/voices',
      generate: '/api/generate',
      export: '/api/export'
    }
  });
});

// 404 handler for undefined routes
app.use((req, res, next) => {
  res.status(404).json({
    error: 'Not Found',
    code: 'NOT_FOUND',
    message: `Route ${req.method} ${req.path} not found`
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err.message);

  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    error: err.name || 'Internal Server Error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'An unexpected error occurred'
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Doppel Center API server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`Health check: http://localhost:${PORT}/health`);
});

module.exports = app;
