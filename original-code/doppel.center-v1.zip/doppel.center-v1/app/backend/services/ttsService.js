/**
 * TTS Service - Provider Abstraction Layer
 *
 * This module provides a unified interface for text-to-speech generation
 * across different providers. Currently supports Twilio (Amazon Polly).
 *
 * Supports two credential modes:
 * 1. Pass-through: Credentials provided per-request
 * 2. House Account: No credentials, uses server-side AWS credentials directly
 */

const voiceRegistry = require('./voiceRegistry');
const twilioProvider = require('./providers/twilio');

/**
 * Map of provider names to their service modules
 */
const providerServices = {
  twilio: twilioProvider
};

/**
 * Generate speech from text using the appropriate provider
 * @param {string} voiceId - The voice identifier (e.g., 'polly-joanna-neural')
 * @param {string} text - The text to convert to speech
 * @param {Object|null} credentials - Provider credentials (null = house account mode)
 * @param {string} credentials.accountSid - Twilio Account SID
 * @param {string} credentials.authToken - Twilio Auth Token
 * @returns {Promise<Object>} Object containing audio buffer and metadata
 */
async function generateSpeech(voiceId, text, credentials) {
  // Validate text
  if (!text || text.trim().length === 0) {
    const error = new Error('Text is required');
    error.statusCode = 400;
    throw error;
  }

  if (text.length > 3000) {
    const error = new Error('Text exceeds maximum length of 3000 characters');
    error.statusCode = 400;
    throw error;
  }

  // Look up voice by ID
  const voice = voiceRegistry.getVoiceById(voiceId);
  if (!voice) {
    const error = new Error(`Voice not found: ${voiceId}`);
    error.statusCode = 404;
    throw error;
  }

  // Get the provider service
  const providerService = providerServices[voice.provider];
  if (!providerService) {
    const error = new Error(`Provider not supported: ${voice.provider}`);
    error.statusCode = 501;
    throw error;
  }

  // Determine mode: house account (null credentials) or pass-through
  const useHouseAccount = !credentials;

  try {
    // Generate audio using the provider
    // Pass credentials as-is (null for house account, object for pass-through)
    const audioBuffer = await providerService.generateAudio(
      voice.providerVoiceId,
      text,
      { format: 'mp3', useHouseAccount },
      credentials
    );

    return {
      audio: audioBuffer,
      format: 'mp3',
      voiceId: voice.id,
      provider: voice.provider,
      textLength: text.length
    };
  } catch (error) {
    // Error Normalization Strategy:
    // Provider implementations may throw various error types. We normalize them here
    // to ensure consistent error handling at the route level.
    //
    // - Errors with statusCode: Already normalized by provider, pass through unchanged
    // - Errors without statusCode: Wrap as 502 PROVIDER_ERROR to indicate external failure
    //
    // This allows routes to rely on error.statusCode for HTTP response codes while
    // preserving the original error message for debugging.
    if (error.statusCode) {
      throw error;
    }
    const serverError = new Error(`Speech generation failed: ${error.message}`);
    serverError.statusCode = 502;
    throw serverError;
  }
}

/**
 * Validate provider credentials
 * @param {string} provider - The provider name (e.g., 'twilio')
 * @param {Object} credentials - Provider credentials
 * @returns {Promise<boolean>} True if credentials are valid
 */
async function validateProviderCredentials(provider, credentials) {
  const providerService = providerServices[provider];
  if (!providerService) {
    const error = new Error(`Provider not supported: ${provider}`);
    error.statusCode = 501;
    throw error;
  }

  return providerService.validateCredentials(credentials);
}

/**
 * Get voice metadata from the provider
 * @param {string} voiceId - The voice identifier
 * @returns {Promise<Object>} Voice metadata
 */
async function getVoiceMetadata(voiceId) {
  const voice = voiceRegistry.getVoiceById(voiceId);
  if (!voice) {
    const error = new Error(`Voice not found: ${voiceId}`);
    error.statusCode = 404;
    throw error;
  }

  const providerService = providerServices[voice.provider];
  if (!providerService) {
    const error = new Error(`Provider not supported: ${voice.provider}`);
    error.statusCode = 501;
    throw error;
  }

  const providerMetadata = await providerService.getVoiceMetadata(voice.providerVoiceId);

  return {
    ...voice,
    providerMetadata
  };
}

module.exports = {
  generateSpeech,
  validateProviderCredentials,
  getVoiceMetadata
};
