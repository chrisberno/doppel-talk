/**
 * Export Service
 * Generates configuration templates for voices in various formats
 */

/**
 * Generate TwiML template for a voice
 * @param {Object} voice - Voice object from registry
 * @returns {string} TwiML XML string
 */
function generateTwiML(voice) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<!-- TwiML Voice Configuration for ${voice.name} -->
<!-- Use this in your Twilio webhook response -->
<Response>
  <Say voice="${voice.providerVoiceId}">
    Your message here
  </Say>
</Response>

<!-- Example with additional options -->
<!--
<Response>
  <Say voice="${voice.providerVoiceId}" language="${voice.language}">
    Hello! This is a sample message using the ${voice.name} voice.
  </Say>
</Response>
-->`;
}

/**
 * Generate Twilio Studio Flow JSON template for a voice
 * @param {Object} voice - Voice object from registry
 * @returns {string} Studio JSON string
 */
function generateStudioJSON(voice) {
  const studioWidget = {
    states: [
      {
        name: "say_message",
        type: "say-play",
        properties: {
          voice: voice.providerVoiceId,
          say: "Your message here",
          language: voice.language,
          loop: 1
        },
        transitions: [
          {
            event: "audioComplete",
            next: "NEXT_WIDGET_NAME"
          }
        ]
      }
    ],
    _comment: `Studio widget configuration for ${voice.name} (${voice.gender}, ${voice.accent || voice.language})`
  };

  return JSON.stringify(studioWidget, null, 2);
}

/**
 * Generate API configuration template for a voice
 * @param {Object} voice - Voice object from registry
 * @returns {string} API config JSON string with usage example
 */
function generateAPIConfig(voice) {
  const config = {
    voiceId: voice.id,
    provider: voice.provider,
    providerVoiceId: voice.providerVoiceId,
    name: voice.name,
    language: voice.language,
    gender: voice.gender,
    accent: voice.accent || null,
    style: voice.style || null
  };

  const usageExample = `
// Voice Configuration
const voiceConfig = ${JSON.stringify(config, null, 2)};

// Example: Generate audio using the Doppel Center API
const response = await fetch('/api/generate', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    voiceId: '${voice.id}',
    text: 'Your message here',
    credentials: {
      accountSid: 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
      authToken: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    }
  })
});

const { audio } = await response.json();

// Convert base64 to blob for playback
const byteCharacters = atob(audio);
const byteNumbers = new Array(byteCharacters.length);
for (let i = 0; i < byteCharacters.length; i++) {
  byteNumbers[i] = byteCharacters.charCodeAt(i);
}
const audioBlob = new Blob([new Uint8Array(byteNumbers)], { type: 'audio/mpeg' });
const audioUrl = URL.createObjectURL(audioBlob);

// Play the audio
const audioElement = new Audio(audioUrl);
audioElement.play();
`;

  return usageExample.trim();
}

module.exports = {
  generateTwiML,
  generateStudioJSON,
  generateAPIConfig
};
