const { voices } = require('../data/voices.json');

/**
 * Provider Metadata Registry
 *
 * Each provider entry defines the metadata shown in the API and frontend.
 * To add a new provider:
 *
 * 1. Add an entry to this array with the following structure:
 *    {
 *      id: string,           // Unique identifier, used in voice.provider field
 *      name: string,         // Display name for the provider
 *      description: string,  // Brief description of the provider
 *      engines: string[],    // Supported engine types (e.g., 'neural', 'generative')
 *      status: string        // 'active', 'coming_soon', or 'deprecated'
 *    }
 *
 * 2. Create the provider implementation in services/providers/{id}.js
 *
 * 3. Register the provider in services/ttsService.js providerServices map
 *
 * 4. Add voices to data/voices.json with provider: '{id}'
 */
const providers = [
  {
    id: 'twilio',
    name: 'Twilio (Amazon Polly)',
    description: 'High-quality neural and generative voices via Twilio\'s Amazon Polly integration',
    engines: ['neural', 'generative'],
    status: 'active'
  }
  // Future providers:
  // { id: 'elevenlabs', name: 'ElevenLabs', description: '...', engines: ['neural'], status: 'coming_soon' }
  // { id: 'hume', name: 'Hume AI', description: '...', engines: ['emotional'], status: 'coming_soon' }
];

/**
 * Get all voices with optional filtering
 * @param {Object} filters - Filter options
 * @param {string} filters.provider - Filter by provider (e.g., 'twilio')
 * @param {string} filters.gender - Filter by gender (e.g., 'male', 'female')
 * @param {string} filters.language - Filter by language code (e.g., 'en-US')
 * @param {string} filters.accent - Filter by accent (e.g., 'american', 'british')
 * @param {string} filters.engine - Filter by engine type (e.g., 'neural', 'generative')
 * @param {string} filters.tags - Comma-separated tags to filter by
 * @param {string} filters.search - Text search across name and tags
 * @returns {Object} Object containing filtered voices array and metadata
 */
function getAllVoices(filters = {}) {
  let result = [...voices];

  // Filter by provider
  if (filters.provider) {
    result = result.filter(voice =>
      voice.provider.toLowerCase() === filters.provider.toLowerCase()
    );
  }

  // Filter by gender
  if (filters.gender) {
    result = result.filter(voice =>
      voice.gender.toLowerCase() === filters.gender.toLowerCase()
    );
  }

  // Filter by language
  if (filters.language) {
    result = result.filter(voice =>
      voice.language.toLowerCase() === filters.language.toLowerCase()
    );
  }

  // Filter by accent
  if (filters.accent) {
    result = result.filter(voice =>
      voice.accent.toLowerCase() === filters.accent.toLowerCase()
    );
  }

  // Filter by engine
  if (filters.engine) {
    result = result.filter(voice =>
      voice.engine.toLowerCase() === filters.engine.toLowerCase()
    );
  }

  // Filter by tags (comma-separated, matches if voice has ANY of the specified tags)
  if (filters.tags) {
    const filterTags = filters.tags.split(',').map(tag => tag.trim().toLowerCase());
    result = result.filter(voice =>
      voice.tags.some(voiceTag =>
        filterTags.includes(voiceTag.toLowerCase())
      )
    );
  }

  // Text search across name and tags
  if (filters.search) {
    const searchTerm = filters.search.toLowerCase();
    result = result.filter(voice =>
      voice.name.toLowerCase().includes(searchTerm) ||
      voice.tags.some(tag => tag.toLowerCase().includes(searchTerm))
    );
  }

  return {
    voices: result,
    meta: {
      total: result.length,
      filters: Object.keys(filters).filter(key => filters[key]).length > 0 ? filters : null
    }
  };
}

/**
 * Get a single voice by ID
 * @param {string} id - The voice ID
 * @returns {Object|null} The voice object or null if not found
 */
function getVoiceById(id) {
  return voices.find(voice => voice.id === id) || null;
}

/**
 * Get list of configured providers
 * @returns {Array} Array of provider metadata objects
 */
function getProviders() {
  return providers;
}

module.exports = {
  getAllVoices,
  getVoiceById,
  getProviders
};
