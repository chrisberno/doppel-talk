/**
 * Twilio Provider Service
 *
 * This module handles TTS generation via Twilio's Amazon Polly integration.
 * Supports two credential modes:
 * 1. Pass-through: Validates Twilio credentials, then uses AWS Polly
 * 2. House Account: Skips Twilio validation, uses server-side AWS credentials directly
 *
 * Since Twilio doesn't offer a standalone TTS API, we use AWS Polly directly
 * with AWS credentials configured server-side.
 */

const twilio = require('twilio');
const { PollyClient, SynthesizeSpeechCommand } = require('@aws-sdk/client-polly');

/**
 * Generate audio from text using Twilio's TTS service
 * @param {string} voiceId - The voice identifier (e.g., 'Polly.Joanna-Neural')
 * @param {string} text - The text to convert to speech
 * @param {Object} options - Generation options
 * @param {string} options.format - Audio format (mp3, wav, etc.)
 * @param {boolean} options.useHouseAccount - If true, skip Twilio credential validation
 * @param {Object|null} credentials - Twilio credentials (null for house account mode)
 * @param {string} credentials.accountSid - Twilio Account SID
 * @param {string} credentials.authToken - Twilio Auth Token
 * @returns {Promise<Buffer>} Audio data buffer
 */
async function generateAudio(voiceId, text, options = {}, credentials) {
  const useHouseAccount = options.useHouseAccount || false;

  // In pass-through mode, credentials are required
  if (!useHouseAccount && (!credentials || !credentials.accountSid || !credentials.authToken)) {
    const error = new Error('Twilio credentials required for pass-through mode');
    error.statusCode = 401;
    throw error;
  }

  if (!voiceId) {
    const error = new Error('Voice ID is required');
    error.statusCode = 400;
    throw error;
  }

  if (!text || text.trim().length === 0) {
    const error = new Error('Text is required');
    error.statusCode = 400;
    throw error;
  }

  if (text.length > 3000) {
    const error = new Error('Text exceeds maximum length of 3000 characters');
    error.statusCode = 400;
    throw error;
  }

  try {
    // In pass-through mode, validate Twilio credentials first
    if (!useHouseAccount) {
      const client = twilio(credentials.accountSid, credentials.authToken);
      await client.api.accounts(credentials.accountSid).fetch();
    }

    // Parse the voice ID to extract Polly voice name and engine
    // Format: "Polly.VoiceName-Engine" (e.g., "Polly.Joanna-Neural")
    const voiceMatch = voiceId.match(/^Polly\.(\w+)-(\w+)$/);
    if (!voiceMatch) {
      const error = new Error(`Invalid voice ID format: ${voiceId}`);
      error.statusCode = 400;
      throw error;
    }

    const [, voiceName, engine] = voiceMatch;

    // AWS Polly Integration:
    // We use AWS Polly directly for audio synthesis. In pass-through mode, we first
    // validate Twilio credentials to verify the user has a valid account. In house
    // account mode, we skip this validation and go straight to AWS Polly.
    //
    // Credential Requirements (both modes):
    // - AWS_ACCESS_KEY_ID: AWS access key with polly:SynthesizeSpeech permission
    // - AWS_SECRET_ACCESS_KEY: Corresponding secret key
    // - AWS_REGION (optional): Defaults to us-east-1
    //
    // If AWS credentials are not set, the PollyClient will attempt to use IAM role
    // credentials (useful for EC2/ECS deployments).
    const pollyClient = new PollyClient({
      region: process.env.AWS_REGION || 'us-east-1',
      credentials: process.env.AWS_ACCESS_KEY_ID ? {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
      } : undefined
    });

    const command = new SynthesizeSpeechCommand({
      Engine: engine.toLowerCase(),
      OutputFormat: 'mp3',
      Text: text,
      VoiceId: voiceName,
      TextType: 'text'
    });

    const response = await pollyClient.send(command);

    // Convert the audio stream to a Buffer
    const chunks = [];
    for await (const chunk of response.AudioStream) {
      chunks.push(chunk);
    }
    const audioBuffer = Buffer.concat(chunks);

    return audioBuffer;
  } catch (error) {
    if (error.code === 20003) {
      const authError = new Error('Invalid Twilio credentials');
      authError.statusCode = 401;
      throw authError;
    }
    if (error.name === 'CredentialsProviderError' || error.name === 'InvalidIdentityTokenException') {
      const authError = new Error('AWS credentials not configured. Please set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY environment variables.');
      authError.statusCode = 401;
      throw authError;
    }
    if (error.$metadata?.httpStatusCode === 400) {
      const badRequest = new Error(`Invalid voice or text: ${error.message}`);
      badRequest.statusCode = 400;
      throw badRequest;
    }
    if (error.statusCode) {
      throw error;
    }
    const serverError = new Error(`TTS generation failed: ${error.message}`);
    serverError.statusCode = 502;
    throw serverError;
  }
}


/**
 * Get detailed metadata for a specific voice from Twilio
 * @param {string} voiceId - The voice identifier
 * @returns {Promise<Object>} Voice metadata from provider
 */
async function getVoiceMetadata(voiceId) {
  // Twilio Polly voices have standard metadata based on voice ID
  const voiceMap = {
    'Polly.Joanna-Neural': { locale: 'en-US', gender: 'Female', engine: 'neural' },
    'Polly.Matthew-Neural': { locale: 'en-US', gender: 'Male', engine: 'neural' },
    'Polly.Ruth-Generative': { locale: 'en-US', gender: 'Female', engine: 'generative' },
    'Polly.Stephen-Generative': { locale: 'en-US', gender: 'Male', engine: 'generative' },
    'Polly.Ivy-Neural': { locale: 'en-US', gender: 'Female', engine: 'neural' },
    'Polly.Joey-Neural': { locale: 'en-US', gender: 'Male', engine: 'neural' },
    'Polly.Amy-Neural': { locale: 'en-GB', gender: 'Female', engine: 'neural' },
    'Polly.Brian-Neural': { locale: 'en-GB', gender: 'Male', engine: 'neural' },
    'Polly.Emma-Neural': { locale: 'en-GB', gender: 'Female', engine: 'neural' },
    'Polly.Lupe-Neural': { locale: 'es-US', gender: 'Female', engine: 'neural' },
    'Polly.Pedro-Neural': { locale: 'es-US', gender: 'Male', engine: 'neural' },
    'Polly.Mia-Neural': { locale: 'es-MX', gender: 'Female', engine: 'neural' },
    'Polly.Camila-Neural': { locale: 'pt-BR', gender: 'Female', engine: 'neural' },
    'Polly.Thiago-Neural': { locale: 'pt-BR', gender: 'Male', engine: 'neural' },
    'Polly.Lea-Neural': { locale: 'fr-FR', gender: 'Female', engine: 'neural' },
    'Polly.Remi-Neural': { locale: 'fr-FR', gender: 'Male', engine: 'neural' }
  };

  const metadata = voiceMap[voiceId];
  if (!metadata) {
    const error = new Error(`Voice not found: ${voiceId}`);
    error.statusCode = 404;
    throw error;
  }

  return {
    voiceId,
    provider: 'twilio',
    ...metadata
  };
}

/**
 * Validate Twilio credentials
 * @param {Object} credentials - Twilio credentials
 * @param {string} credentials.accountSid - Twilio Account SID
 * @param {string} credentials.authToken - Twilio Auth Token
 * @returns {Promise<boolean>} True if credentials are valid
 */
async function validateCredentials(credentials) {
  if (!credentials || !credentials.accountSid || !credentials.authToken) {
    return false;
  }

  // Validate format
  if (!credentials.accountSid.startsWith('AC') || credentials.accountSid.length !== 34) {
    return false;
  }

  if (credentials.authToken.length !== 32) {
    return false;
  }

  try {
    const client = twilio(credentials.accountSid, credentials.authToken);
    // Make a simple API call to validate credentials
    await client.api.accounts(credentials.accountSid).fetch();
    return true;
  } catch (error) {
    if (error.code === 20003) {
      return false; // Invalid credentials
    }
    throw error;
  }
}

module.exports = {
  generateAudio,
  getVoiceMetadata,
  validateCredentials
};
