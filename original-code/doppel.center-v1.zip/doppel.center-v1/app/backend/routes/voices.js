const express = require('express');
const router = express.Router();
const voiceRegistry = require('../services/voiceRegistry');

/**
 * GET /api/voices
 * Get all voices with optional filtering
 *
 * Query Parameters:
 * - provider: Filter by provider (e.g., 'twilio')
 * - gender: Filter by gender ('male', 'female')
 * - language: Filter by language code (e.g., 'en-US', 'es-MX')
 * - accent: Filter by accent (e.g., 'american', 'british', 'brazilian')
 * - engine: Filter by engine type ('neural', 'generative')
 * - tags: Comma-separated tags to filter by (e.g., 'professional,warm')
 * - search: Text search across name and tags
 */
router.get('/voices', (req, res, next) => {
  try {
    const filters = {
      provider: req.query.provider,
      gender: req.query.gender,
      language: req.query.language,
      accent: req.query.accent,
      engine: req.query.engine,
      tags: req.query.tags,
      search: req.query.search
    };

    // Remove undefined values
    Object.keys(filters).forEach(key => {
      if (filters[key] === undefined) {
        delete filters[key];
      }
    });

    const result = voiceRegistry.getAllVoices(filters);

    res.json(result);
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/voices/:id
 * Get a single voice by ID
 */
router.get('/voices/:id', (req, res, next) => {
  try {
    const voice = voiceRegistry.getVoiceById(req.params.id);

    if (!voice) {
      return res.status(404).json({
        error: 'Not Found',
        code: 'NOT_FOUND',
        message: `Voice with ID '${req.params.id}' not found`
      });
    }

    res.json(voice);
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/providers
 * Get list of configured voice providers
 */
router.get('/providers', (req, res, next) => {
  try {
    const providers = voiceRegistry.getProviders();
    res.json({
      providers,
      meta: {
        total: providers.length
      }
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
