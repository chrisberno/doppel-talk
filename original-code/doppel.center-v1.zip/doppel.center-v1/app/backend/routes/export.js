const express = require('express');
const router = express.Router();
const voiceRegistry = require('../services/voiceRegistry');
const exportService = require('../services/exportService');

/**
 * POST /api/export/:format
 * Generate export configuration for a voice in various formats
 *
 * Path parameters:
 * - format: Export format ('twiml', 'studio', or 'api')
 *
 * Request body:
 * {
 *   voiceId: string  // Voice ID from the registry
 * }
 *
 * Response:
 * {
 *   format: string,  // The requested format
 *   config: string   // The generated configuration
 * }
 */
router.post('/export/:format', async (req, res) => {
  try {
    const { voiceId } = req.body;
    const { format } = req.params;

    // Validate format parameter
    const validFormats = ['twiml', 'studio', 'api'];
    if (!validFormats.includes(format)) {
      return res.status(400).json({
        error: `Invalid format '${format}'. Supported formats: ${validFormats.join(', ')}`,
        code: 'INVALID_FORMAT'
      });
    }

    // Validate voiceId presence
    if (!voiceId) {
      return res.status(400).json({
        error: 'Missing required field: voiceId',
        code: 'MISSING_VOICE_ID'
      });
    }

    // Validate voiceId type and format
    if (typeof voiceId !== 'string' || voiceId.trim().length === 0) {
      return res.status(400).json({
        error: 'voiceId must be a non-empty string',
        code: 'INVALID_VOICE_ID'
      });
    }

    // Look up voice in registry
    const voice = voiceRegistry.getVoiceById(voiceId);
    if (!voice) {
      return res.status(404).json({
        error: `Voice not found: ${voiceId}`,
        code: 'NOT_FOUND'
      });
    }

    // Generate configuration based on format
    let config;
    switch (format) {
      case 'twiml':
        config = exportService.generateTwiML(voice);
        break;
      case 'studio':
        config = exportService.generateStudioJSON(voice);
        break;
      case 'api':
        config = exportService.generateAPIConfig(voice);
        break;
    }

    res.json({ format, config });
  } catch (error) {
    console.error('Export error:', error.message);

    // Use error's status code if available, otherwise 500
    const statusCode = error.statusCode || 500;
    res.status(statusCode).json({
      error: statusCode === 500 ? 'Failed to generate export configuration' : error.message,
      code: getErrorCode(statusCode)
    });
  }
});

/**
 * Get error code based on HTTP status
 * @param {number} statusCode - HTTP status code
 * @returns {string} Machine-readable error code
 */
function getErrorCode(statusCode) {
  const codes = {
    400: 'BAD_REQUEST',
    401: 'UNAUTHORIZED',
    404: 'NOT_FOUND',
    500: 'INTERNAL_ERROR'
  };
  return codes[statusCode] || 'UNKNOWN_ERROR';
}

module.exports = router;
