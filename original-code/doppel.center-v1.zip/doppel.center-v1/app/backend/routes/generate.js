/**
 * Generation Routes
 *
 * API endpoints for text-to-speech generation.
 * Supports two credential modes:
 * 1. Pass-through: Credentials sent per-request (validates against Twilio first)
 * 2. House Account: No credentials required, uses server-side AWS credentials directly
 */

const express = require('express');
const router = express.Router();
const ttsService = require('../services/ttsService');

/**
 * POST /api/generate
 * Generate audio from text using specified voice
 *
 * Request body:
 * {
 *   voiceId: string,      // Voice ID from voices registry (e.g., 'polly-joanna-neural')
 *   text: string,         // Text to convert to speech (max 3000 characters)
 *   credentials?: {       // Optional - if omitted, uses house account
 *     accountSid: string, // Twilio Account SID (starts with 'AC')
 *     authToken: string   // Twilio Auth Token (32 characters)
 *   }
 * }
 *
 * Response:
 * {
 *   audio: string,        // Base64-encoded audio data
 *   format: string,       // Audio format (e.g., 'mp3')
 *   voiceId: string,      // Voice ID used
 *   textLength: number,   // Length of text processed
 *   mode: string          // 'house_account' or 'pass_through'
 * }
 */
router.post('/generate', async (req, res) => {
  try {
    const { voiceId, text, credentials } = req.body;

    // Validate required fields
    if (!voiceId) {
      return res.status(400).json({
        error: 'Missing required field: voiceId',
        code: 'MISSING_VOICE_ID'
      });
    }

    if (!text) {
      return res.status(400).json({
        error: 'Missing required field: text',
        code: 'MISSING_TEXT'
      });
    }

    // Validate text length
    if (text.length > 3000) {
      return res.status(400).json({
        error: 'Text exceeds maximum length of 3000 characters',
        code: 'TEXT_TOO_LONG',
        maxLength: 3000,
        actualLength: text.length
      });
    }

    // Determine credential mode
    const useHouseAccount = !credentials;
    let validatedCredentials = null;

    if (!useHouseAccount) {
      // Pass-through mode: validate provided credentials
      if (!credentials.accountSid || !credentials.authToken) {
        return res.status(401).json({
          error: 'Credentials must include accountSid and authToken',
          code: 'INVALID_CREDENTIALS_FORMAT'
        });
      }

      if (!credentials.accountSid.startsWith('AC') || credentials.accountSid.length !== 34) {
        return res.status(401).json({
          error: 'Invalid Account SID format. Must start with "AC" and be 34 characters.',
          code: 'INVALID_ACCOUNT_SID'
        });
      }

      if (credentials.authToken.length !== 32) {
        return res.status(401).json({
          error: 'Invalid Auth Token format. Must be 32 characters.',
          code: 'INVALID_AUTH_TOKEN'
        });
      }

      validatedCredentials = credentials;
    }

    // Generate speech (null credentials = house account mode)
    const result = await ttsService.generateSpeech(voiceId, text, validatedCredentials);

    // Convert buffer to base64
    const audioBase64 = result.audio.toString('base64');

    res.json({
      audio: audioBase64,
      format: result.format,
      voiceId: result.voiceId,
      textLength: result.textLength,
      mode: useHouseAccount ? 'house_account' : 'pass_through'
    });
  } catch (error) {
    console.error('Generation error:', error.message);

    const statusCode = error.statusCode || 500;
    const errorResponse = {
      error: error.message,
      code: getErrorCode(statusCode)
    };

    res.status(statusCode).json(errorResponse);
  }
});

/**
 * POST /api/validate-credentials
 * Validate provider credentials without generating audio
 *
 * Request body:
 * {
 *   provider: string,     // Provider name (e.g., 'twilio')
 *   credentials: {
 *     accountSid: string,
 *     authToken: string
 *   }
 * }
 *
 * Response:
 * {
 *   valid: boolean
 * }
 */
router.post('/validate-credentials', async (req, res) => {
  try {
    const { provider = 'twilio', credentials } = req.body;

    if (!credentials || !credentials.accountSid || !credentials.authToken) {
      return res.status(400).json({
        error: 'Credentials must include accountSid and authToken',
        code: 'INVALID_CREDENTIALS_FORMAT'
      });
    }

    const valid = await ttsService.validateProviderCredentials(provider, credentials);

    res.json({ valid });
  } catch (error) {
    console.error('Validation error:', error.message);

    const statusCode = error.statusCode || 500;
    res.status(statusCode).json({
      error: error.message,
      code: getErrorCode(statusCode)
    });
  }
});

/**
 * Get error code based on HTTP status
 */
function getErrorCode(statusCode) {
  const codes = {
    400: 'BAD_REQUEST',
    401: 'UNAUTHORIZED',
    404: 'NOT_FOUND',
    501: 'NOT_IMPLEMENTED',
    502: 'PROVIDER_ERROR',
    500: 'INTERNAL_ERROR'
  };
  return codes[statusCode] || 'UNKNOWN_ERROR';
}

module.exports = router;
