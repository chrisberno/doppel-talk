/**
 * Export Modal Module
 * Handles the export configuration modal for voices
 */

// API Configuration
// Read from global, data attribute on body, or default to localhost:3000
const API_BASE_URL = window.API_BASE_URL
    || document.body.dataset.apiBaseUrl
    || 'http://localhost:3000/api';

// DOM Elements
let modal = null;
let closeBtn = null;
let voiceNameSpan = null;
let tabs = null;
let codeBlock = null;
let codeElement = null;
let copyBtn = null;
let loadingElement = null;

// State
let currentVoiceId = null;
let currentVoiceName = null;
let currentFormat = 'twiml';
let cachedConfigs = {};

/**
 * Initialize the export modal
 */
export function initializeExportModal() {
    // Get DOM elements
    modal = document.getElementById('export-modal');
    closeBtn = document.getElementById('export-close-btn');
    voiceNameSpan = document.getElementById('export-voice-name');
    tabs = document.querySelectorAll('.export-tab');
    codeBlock = document.getElementById('export-code-block');
    codeElement = document.getElementById('export-code');
    copyBtn = document.getElementById('export-copy-btn');
    loadingElement = document.getElementById('export-loading');

    if (!modal) {
        console.error('Export modal not found');
        return;
    }

    // Attach event listeners
    closeBtn.addEventListener('click', close);
    modal.addEventListener('click', handleOverlayClick);
    copyBtn.addEventListener('click', handleCopy);

    tabs.forEach(tab => {
        tab.addEventListener('click', () => handleTabClick(tab));
    });

    // Handle escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            close();
        }
    });

    // Expose to window for voice cards
    window.exportModal = {
        open,
        close
    };
}

/**
 * Open the export modal
 * @param {string} voiceId - Voice ID
 * @param {string} voiceName - Voice display name
 * @param {string} providerVoiceId - Provider-specific voice ID
 */
function open(voiceId, voiceName, providerVoiceId) {
    currentVoiceId = voiceId;
    currentVoiceName = voiceName;
    cachedConfigs = {}; // Clear cache for new voice

    voiceNameSpan.textContent = voiceName;

    // Reset to first tab
    setActiveTab('twiml');

    // Show modal
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';

    // Fetch initial configuration
    fetchConfig('twiml');
}

/**
 * Close the export modal
 */
function close() {
    modal.classList.remove('active');
    document.body.style.overflow = '';
    currentVoiceId = null;
    currentVoiceName = null;
    cachedConfigs = {};
}

/**
 * Handle overlay click to close modal
 * @param {Event} event - Click event
 */
function handleOverlayClick(event) {
    if (event.target === modal) {
        close();
    }
}

/**
 * Handle tab click
 * @param {HTMLElement} tab - Clicked tab element
 */
function handleTabClick(tab) {
    const format = tab.dataset.format;
    if (format === currentFormat) return;

    setActiveTab(format);
    fetchConfig(format);
}

/**
 * Set the active tab
 * @param {string} format - Format to activate
 */
function setActiveTab(format) {
    currentFormat = format;

    tabs.forEach(tab => {
        if (tab.dataset.format === format) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });

    // Update code element class for syntax highlighting
    const languageClass = getLanguageClass(format);
    codeElement.className = languageClass;
}

/**
 * Get Prism language class for format
 * @param {string} format - Export format
 * @returns {string} Prism language class
 */
function getLanguageClass(format) {
    switch (format) {
        case 'twiml':
            return 'language-xml';
        case 'studio':
            return 'language-json';
        case 'api':
            return 'language-javascript';
        default:
            return 'language-xml';
    }
}

// Request timeout configuration
const REQUEST_TIMEOUT_MS = 10000; // 10 second timeout
let currentFetchController = null;

/**
 * Fetch configuration from API with timeout handling
 * @param {string} format - Export format
 */
async function fetchConfig(format) {
    // Check cache first
    if (cachedConfigs[format]) {
        displayCode(cachedConfigs[format]);
        return;
    }

    // Cancel any pending request
    if (currentFetchController) {
        currentFetchController.abort();
    }

    // Create new abort controller for this request
    currentFetchController = new AbortController();
    const timeoutId = setTimeout(() => {
        currentFetchController.abort();
    }, REQUEST_TIMEOUT_MS);

    // Show loading state
    showLoading(true);

    try {
        const response = await fetch(`${API_BASE_URL}/export/${format}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                voiceId: currentVoiceId
            }),
            signal: currentFetchController.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to fetch configuration');
        }

        const data = await response.json();
        cachedConfigs[format] = data.config;
        displayCode(data.config);
    } catch (error) {
        clearTimeout(timeoutId);

        if (error.name === 'AbortError') {
            // Request timed out or was cancelled
            displayError('Request timed out. Click a tab to retry.');
        } else {
            console.error('Error fetching config:', error);
            displayError(error.message);
        }
    } finally {
        showLoading(false);
        currentFetchController = null;
    }
}

/**
 * Display code in the code block
 * @param {string} code - Code to display
 */
function displayCode(code) {
    codeElement.textContent = code;

    // Apply syntax highlighting
    if (window.Prism) {
        Prism.highlightElement(codeElement);
    }

    codeBlock.style.display = 'block';
}

/**
 * Display error message
 * @param {string} message - Error message
 */
function displayError(message) {
    codeElement.textContent = `Error: ${message}`;
    codeBlock.style.display = 'block';
}

/**
 * Show or hide loading state
 * @param {boolean} show - Whether to show loading
 */
function showLoading(show) {
    if (show) {
        loadingElement.style.display = 'flex';
        codeBlock.style.display = 'none';
    } else {
        loadingElement.style.display = 'none';
        codeBlock.style.display = 'block';
    }
}

/**
 * Handle copy button click
 */
async function handleCopy() {
    const code = cachedConfigs[currentFormat];
    if (!code) return;

    try {
        await navigator.clipboard.writeText(code);
        showCopySuccess();
    } catch (error) {
        console.error('Failed to copy:', error);
        // Fallback for older browsers
        fallbackCopy(code);
    }
}

/**
 * Show copy success feedback
 */
function showCopySuccess() {
    const copyText = copyBtn.querySelector('.copy-text');
    const originalText = copyText.textContent;

    copyBtn.classList.add('success');
    copyText.textContent = 'Copied!';

    setTimeout(() => {
        copyBtn.classList.remove('success');
        copyText.textContent = originalText;
    }, 2000);
}

/**
 * Fallback copy method for older browsers
 * @param {string} text - Text to copy
 */
function fallbackCopy(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();

    try {
        document.execCommand('copy');
        showCopySuccess();
    } catch (error) {
        console.error('Fallback copy failed:', error);
    }

    document.body.removeChild(textarea);
}
