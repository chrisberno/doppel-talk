/**
 * Voice card rendering module
 * Handles creating and displaying voice cards in the grid
 */

// DOM Elements
const voiceGrid = document.getElementById('voice-grid');
const resultsCount = document.getElementById('results-count');
const emptyState = document.getElementById('empty-state');

/**
 * Create HTML for a single voice card
 * @param {Object} voice - Voice object with all metadata
 * @returns {string} HTML string for the card
 */
function createVoiceCard(voice) {
    const firstLetter = voice.name.charAt(0).toUpperCase();
    const engineClass = voice.engine === 'neural' ? 'status-neural' : 'status-generative';
    const providerClass = voice.provider === 'twilio' ? 'provider-twilio' : 'provider-polly';
    const providerLabel = voice.provider === 'twilio' ? 'Twilio' : 'Polly';

    const tagsHtml = voice.tags && voice.tags.length > 0
        ? voice.tags.map(tag => `<span class="tag">${escapeHtml(tag)}</span>`).join('')
        : '';

    // Check if script exists to determine Preview Script button visibility
    const hasScript = window.audioPlayer && window.audioPlayer.hasScript && window.audioPlayer.hasScript();
    const previewScriptStyle = hasScript ? '' : 'style="display: none;"';

    return `
        <div class="voice-card card" data-voice-id="${escapeHtml(voice.id)}">
            <div class="card-header">
                <div class="card-icon">${firstLetter}</div>
                <span class="card-status ${engineClass}">${escapeHtml(voice.engine)}</span>
            </div>
            <div class="card-provider">
                <span class="provider-badge ${providerClass}">${providerLabel}</span>
            </div>
            <h3 class="card-title">${escapeHtml(voice.name)}</h3>
            <p class="card-description">${escapeHtml(voice.previewText || '')}</p>
            <div class="card-metadata">
                <div class="metadata-item">
                    <span class="metadata-label">Language</span>
                    <span class="metadata-value">${escapeHtml(voice.language)}</span>
                </div>
                <div class="metadata-item">
                    <span class="metadata-label">Accent</span>
                    <span class="metadata-value">${escapeHtml(formatAccent(voice.accent))}</span>
                </div>
                <div class="metadata-item">
                    <span class="metadata-label">Gender</span>
                    <span class="metadata-value">${escapeHtml(capitalize(voice.gender))}</span>
                </div>
            </div>
            <div class="card-tags">
                ${tagsHtml}
            </div>
            <div class="card-actions">
                <button
                    type="button"
                    class="play-sample-btn btn btn-secondary"
                    data-voice-id="${escapeHtml(voice.id)}"
                    data-sample-url="${escapeHtml(voice.sampleAudioUrl || '')}"
                    data-voice-name="${escapeHtml(voice.name)}"
                    data-voice-provider="${escapeHtml(voice.provider)}"
                >
                    <svg viewBox="0 0 24 24" width="16" height="16" class="btn-icon">
                        <polygon points="5,3 19,12 5,21" fill="currentColor"/>
                    </svg>
                    Play Sample
                </button>
                <button
                    type="button"
                    class="preview-script-btn btn btn-primary"
                    data-voice-id="${escapeHtml(voice.id)}"
                    data-voice-name="${escapeHtml(voice.name)}"
                    data-voice-provider="${escapeHtml(voice.provider)}"
                    ${previewScriptStyle}
                >
                    <svg viewBox="0 0 24 24" width="16" height="16" class="btn-icon">
                        <path d="M3 9v6h4l5 5V4L7 9H3z" fill="currentColor"/>
                        <path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z" fill="currentColor"/>
                    </svg>
                    Preview Script
                </button>
                <button
                    type="button"
                    class="export-config-btn btn btn-secondary"
                    data-voice-id="${escapeHtml(voice.id)}"
                    data-voice-name="${escapeHtml(voice.name)}"
                    data-provider-voice-id="${escapeHtml(voice.providerVoiceId || '')}"
                >
                    <svg viewBox="0 0 24 24" width="16" height="16" class="btn-icon">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" fill="none" stroke="currentColor" stroke-width="2"/>
                        <polyline points="14 2 14 8 20 8" fill="none" stroke="currentColor" stroke-width="2"/>
                        <line x1="9" y1="13" x2="15" y2="13" stroke="currentColor" stroke-width="2"/>
                        <line x1="9" y1="17" x2="15" y2="17" stroke="currentColor" stroke-width="2"/>
                    </svg>
                    Export Config
                </button>
            </div>
        </div>
    `;
}

/**
 * Render voice cards to the grid
 * @param {Array} voices - Array of voice objects to display
 */
export function renderVoices(voices) {
    // Update results count
    const count = voices.length;
    resultsCount.textContent = `${count} voice${count !== 1 ? 's' : ''} found`;

    // Handle empty state
    if (count === 0) {
        voiceGrid.innerHTML = '';
        voiceGrid.hidden = true;
        emptyState.hidden = false;
        return;
    }

    // Hide empty state and show grid
    emptyState.hidden = true;
    voiceGrid.hidden = false;

    // Render all voice cards
    const cardsHtml = voices.map(voice => createVoiceCard(voice)).join('');
    voiceGrid.innerHTML = cardsHtml;

    // Attach event listeners to buttons
    attachCardEventListeners();
}

/**
 * Attach event listeners to voice card buttons
 */
function attachCardEventListeners() {
    // Play Sample buttons
    document.querySelectorAll('.play-sample-btn').forEach(btn => {
        btn.addEventListener('click', handlePlaySample);
    });

    // Preview Script buttons
    document.querySelectorAll('.preview-script-btn').forEach(btn => {
        btn.addEventListener('click', handlePreviewScript);
    });

    // Export Config buttons
    document.querySelectorAll('.export-config-btn').forEach(btn => {
        btn.addEventListener('click', handleExportConfig);
    });
}

/**
 * Handle Export Config button click
 * @param {Event} event - Click event
 */
function handleExportConfig(event) {
    const btn = event.currentTarget;
    const voiceId = btn.dataset.voiceId;
    const voiceName = btn.dataset.voiceName;
    const providerVoiceId = btn.dataset.providerVoiceId;

    if (window.exportModal) {
        window.exportModal.open(voiceId, voiceName, providerVoiceId);
    }
}

/**
 * Handle Play Sample button click
 * @param {Event} event - Click event
 */
function handlePlaySample(event) {
    const btn = event.currentTarget;
    const voiceId = btn.dataset.voiceId;
    const sampleUrl = btn.dataset.sampleUrl;
    const voiceName = btn.dataset.voiceName;
    const voiceProvider = btn.dataset.voiceProvider;

    if (!sampleUrl) {
        console.warn('No sample URL available for voice:', voiceId);
        return;
    }

    if (window.audioPlayer) {
        window.audioPlayer.playSample(voiceId, sampleUrl, {
            name: voiceName,
            provider: voiceProvider
        });
    }
}

/**
 * Handle Preview Script button click
 * @param {Event} event - Click event
 */
function handlePreviewScript(event) {
    const btn = event.currentTarget;
    const voiceId = btn.dataset.voiceId;
    const voiceName = btn.dataset.voiceName;
    const voiceProvider = btn.dataset.voiceProvider;

    if (window.audioPlayer) {
        const scriptText = window.audioPlayer.getScriptText();

        if (!scriptText || scriptText.trim().length === 0) {
            // Focus the script textarea
            const textarea = document.getElementById('script-textarea');
            if (textarea) {
                textarea.focus();
            }
            return;
        }

        // Set loading state on button
        btn.disabled = true;
        btn.innerHTML = `
            <div class="loading-spinner small"></div>
            Generating...
        `;

        window.audioPlayer.playScript(voiceId, scriptText, {
            name: voiceName,
            provider: voiceProvider
        }).finally(() => {
            // Reset button state
            btn.disabled = false;
            btn.innerHTML = `
                <svg viewBox="0 0 24 24" width="16" height="16" class="btn-icon">
                    <path d="M3 9v6h4l5 5V4L7 9H3z" fill="currentColor"/>
                    <path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z" fill="currentColor"/>
                </svg>
                Preview Script
            `;
        });
    }
}

/**
 * Escape HTML special characters to prevent XSS
 * @param {string} str - String to escape
 * @returns {string} Escaped string
 */
function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

/**
 * Capitalize first letter of a string
 * @param {string} str - String to capitalize
 * @returns {string} Capitalized string
 */
function capitalize(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

/**
 * Format accent string for display
 * @param {string} accent - Accent value (e.g., "mexican-spanish")
 * @returns {string} Formatted accent (e.g., "Mexican Spanish")
 */
function formatAccent(accent) {
    if (!accent) return '';
    return accent
        .split('-')
        .map(word => capitalize(word))
        .join(' ');
}
