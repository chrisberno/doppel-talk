/**
 * Filter and search logic module
 * Handles all filtering operations for the voice gallery
 */

import { renderVoices } from './voices.js';

// Store reference to all voices
let allVoices = [];

// DOM Elements
const searchInput = document.getElementById('search-input');
const clearFiltersBtn = document.getElementById('clear-filters');
const clearFiltersEmptyBtn = document.getElementById('clear-filters-empty');

// Debounce timer
let searchDebounceTimer = null;

/**
 * Initialize filters with voice data
 * @param {Array} voices - All available voices
 */
export function initializeFilters(voices) {
    allVoices = voices;

    // Attach event listeners to all filter checkboxes
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', applyFilters);
    });

    // Attach debounced search listener
    searchInput.addEventListener('input', handleSearchInput);

    // Clear filters buttons
    clearFiltersBtn.addEventListener('click', clearAllFilters);
    clearFiltersEmptyBtn.addEventListener('click', clearAllFilters);

    // Apply filters to handle URL parameters on initial load
    applyFilters();
}

/**
 * Handle search input with debounce
 */
function handleSearchInput() {
    // Clear existing timer
    if (searchDebounceTimer) {
        clearTimeout(searchDebounceTimer);
    }

    // Set new timer
    searchDebounceTimer = setTimeout(() => {
        applyFilters();
    }, 300);
}

/**
 * Get currently selected values for a filter group
 * @param {string} name - Filter group name (e.g., "provider", "gender")
 * @returns {Array} Array of selected values
 */
function getSelectedValues(name) {
    const checkboxes = document.querySelectorAll(`input[name="${name}"]:checked`);
    return Array.from(checkboxes).map(cb => cb.value);
}

/**
 * Apply all active filters and update display
 */
export function applyFilters() {
    let filtered = [...allVoices];

    // Get current filter states
    const searchTerm = searchInput.value.toLowerCase().trim();
    const selectedProviders = getSelectedValues('provider');
    const selectedGenders = getSelectedValues('gender');
    const selectedLanguages = getSelectedValues('language');
    const selectedAccents = getSelectedValues('accent');
    const selectedEngines = getSelectedValues('engine');
    const selectedTones = getSelectedValues('tone');
    const selectedTags = getSelectedValues('tags');

    // Apply search filter (searches name and tags)
    if (searchTerm) {
        filtered = filtered.filter(voice => {
            const nameMatch = voice.name.toLowerCase().includes(searchTerm);
            const tagMatch = voice.tags && voice.tags.some(tag =>
                tag.toLowerCase().includes(searchTerm)
            );
            return nameMatch || tagMatch;
        });
    }

    // Apply provider filter
    if (selectedProviders.length > 0) {
        filtered = filtered.filter(voice =>
            selectedProviders.includes(voice.provider)
        );
    }

    // Apply gender filter
    if (selectedGenders.length > 0) {
        filtered = filtered.filter(voice =>
            selectedGenders.includes(voice.gender)
        );
    }

    // Apply language filter
    if (selectedLanguages.length > 0) {
        filtered = filtered.filter(voice =>
            selectedLanguages.includes(voice.language)
        );
    }

    // Apply accent filter
    if (selectedAccents.length > 0) {
        filtered = filtered.filter(voice =>
            selectedAccents.includes(voice.accent)
        );
    }

    // Apply engine filter
    if (selectedEngines.length > 0) {
        filtered = filtered.filter(voice =>
            selectedEngines.includes(voice.engine)
        );
    }

    // Apply tone filter
    if (selectedTones.length > 0) {
        filtered = filtered.filter(voice =>
            selectedTones.includes(voice.tone)
        );
    }

    // Apply tags filter (matches if voice has ANY of selected tags)
    if (selectedTags.length > 0) {
        filtered = filtered.filter(voice =>
            voice.tags && voice.tags.some(tag =>
                selectedTags.includes(tag)
            )
        );
    }

    // Update display
    renderVoices(filtered);

    // Update URL query parameters (optional feature)
    updateUrlParams({
        search: searchTerm,
        provider: selectedProviders,
        gender: selectedGenders,
        language: selectedLanguages,
        accent: selectedAccents,
        engine: selectedEngines,
        tone: selectedTones,
        tags: selectedTags
    });
}

/**
 * Clear all filters and reset to default state
 */
function clearAllFilters() {
    // Clear search input
    searchInput.value = '';

    // Uncheck all checkboxes
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    checkboxes.forEach(checkbox => {
        checkbox.checked = false;
    });

    // Clear URL parameters
    window.history.replaceState({}, '', window.location.pathname);

    // Re-apply filters (will show all voices)
    applyFilters();
}

/**
 * Update URL query parameters to reflect active filters
 * @param {Object} filters - Current filter state
 */
function updateUrlParams(filters) {
    const params = new URLSearchParams();

    if (filters.search) {
        params.set('search', filters.search);
    }

    Object.entries(filters).forEach(([key, values]) => {
        if (key !== 'search' && Array.isArray(values) && values.length > 0) {
            params.set(key, values.join(','));
        }
    });

    const queryString = params.toString();
    const newUrl = queryString
        ? `${window.location.pathname}?${queryString}`
        : window.location.pathname;

    window.history.replaceState({}, '', newUrl);
}

/**
 * Parse URL parameters and apply filters on page load
 */
function parseUrlParams() {
    const params = new URLSearchParams(window.location.search);

    // Set search input
    const search = params.get('search');
    if (search) {
        searchInput.value = search;
    }

    // Set checkboxes
    const filterNames = ['provider', 'gender', 'language', 'accent', 'engine', 'tone', 'tags'];
    filterNames.forEach(name => {
        const values = params.get(name);
        if (values) {
            const valueArray = values.split(',');
            valueArray.forEach(value => {
                const checkbox = document.querySelector(`input[name="${name}"][value="${value}"]`);
                if (checkbox) {
                    checkbox.checked = true;
                }
            });
        }
    });
}

// Parse URL params on module load (after DOM is ready)
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', parseUrlParams);
} else {
    parseUrlParams();
}
