/**
 * Audition Page - Airline-Style Voice Filtering Experience
 *
 * Left sidebar filters, voice card results in center, audio player at bottom.
 * User enters script in banner, filters voices, clicks to generate TTS.
 */

// API Configuration
const API_BASE_URL = window.API_BASE_URL
    || document.body.dataset.apiBaseUrl
    || 'https://doppel.center/api';

// State
let allVoices = [];
let filteredVoices = [];
let activeFilters = {
    language: [],
    gender: [],
    engine: [],
    tone: [],
    useCase: []
};
let audioElement = null;
let currentlyPlayingId = null;

// DOM Elements
const scriptInput = document.getElementById('audition-script');
const charCount = document.getElementById('char-count');
const clearScriptBtn = document.getElementById('clear-script');
const clearFiltersBtn = document.getElementById('clear-filters');
const clearFiltersEmptyBtn = document.getElementById('clear-filters-empty');
const shuffleBtn = document.getElementById('shuffle-btn');
const resultsCount = document.getElementById('results-count');
const voiceResults = document.getElementById('voice-results');
const noResults = document.getElementById('no-results');

// Audio player elements
const audioPlayer = document.getElementById('audio-player');
const playerAvatarContainer = document.getElementById('player-avatar-container');
const playerAvatar = document.getElementById('player-avatar');
const playerVoiceName = document.getElementById('player-voice-name');
const playerPlayBtn = document.getElementById('player-play-btn');
const playIcon = document.getElementById('play-icon');
const pauseIcon = document.getElementById('pause-icon');
const playerLoading = document.getElementById('player-loading');
const playerCurrent = document.getElementById('player-current');
const playerDuration = document.getElementById('player-duration');
const playerSeek = document.getElementById('player-seek');
const playerVolume = document.getElementById('player-volume');

// Error toast
const errorToast = document.getElementById('error-toast');
const errorMessage = document.getElementById('error-message');

/**
 * Initialize the page
 */
async function init() {
    // Create audio element
    audioElement = new Audio();
    setupAudioListeners();

    // Load voices
    await loadVoices();

    // Setup event listeners
    setupEventListeners();

    // Load saved script if any
    const savedScript = localStorage.getItem('audition_script');
    if (savedScript) {
        scriptInput.value = savedScript;
        updateCharCount();
    }
}

/**
 * Load voices from API
 */
async function loadVoices() {
    try {
        const response = await fetch(`${API_BASE_URL}/voices`);
        if (!response.ok) throw new Error('Failed to load voices');

        const data = await response.json();
        allVoices = data.voices || [];

        // Update filter counts and display
        updateFilterCounts();
        applyFilters();
    } catch (error) {
        console.error('Error loading voices:', error);
        showError('Failed to load voices. Please refresh the page.');
        voiceResults.innerHTML = '<p class="error-message">Failed to load voices</p>';
    }
}

/**
 * Update the count badges on each filter option
 */
function updateFilterCounts() {
    document.querySelectorAll('.filter-count').forEach(countEl => {
        const filterType = countEl.dataset.filter;
        const filterValue = countEl.dataset.value;

        const count = allVoices.filter(voice => {
            if (filterType === 'language') return voice.language === filterValue;
            if (filterType === 'gender') return voice.gender === filterValue;
            if (filterType === 'engine') return voice.engine === filterValue;
            if (filterType === 'tone') return voice.tags?.includes(filterValue);
            if (filterType === 'useCase') return voice.useCases?.includes(filterValue);
            return false;
        }).length;

        countEl.textContent = count > 0 ? `(${count})` : '';
    });
}

/**
 * Apply current filters and update displayed voices
 */
function applyFilters() {
    filteredVoices = allVoices.filter(voice => {
        // Language filter (OR within category)
        if (activeFilters.language.length > 0) {
            if (!activeFilters.language.includes(voice.language)) return false;
        }

        // Gender filter
        if (activeFilters.gender.length > 0) {
            if (!activeFilters.gender.includes(voice.gender)) return false;
        }

        // Engine filter
        if (activeFilters.engine.length > 0) {
            if (!activeFilters.engine.includes(voice.engine)) return false;
        }

        // Tone filter (check tags)
        if (activeFilters.tone.length > 0) {
            const voiceTones = voice.tags || [];
            if (!activeFilters.tone.some(t => voiceTones.includes(t))) return false;
        }

        // Use case filter
        if (activeFilters.useCase.length > 0) {
            const voiceUseCases = voice.useCases || [];
            if (!activeFilters.useCase.some(u => voiceUseCases.includes(u))) return false;
        }

        return true;
    });

    renderVoiceCards();
    updateResultsCount();
}

/**
 * Render voice cards in the results area
 */
function renderVoiceCards() {
    if (filteredVoices.length === 0) {
        voiceResults.innerHTML = '';
        noResults.hidden = false;
        return;
    }

    noResults.hidden = true;

    voiceResults.innerHTML = filteredVoices.map(voice => {
        const isPlaying = currentlyPlayingId === voice.id;
        const tags = voice.tags || [];
        const firstTag = tags[0] || voice.engine;

        // SVG silhouette path
        const silhouettePath = 'M12 2C9.79 2 8 3.79 8 6s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm0 10c-3.25 0-6 1.34-6 3v2h12v-2c0-1.66-2.75-3-6-3z';

        return `
            <div class="voice-card ${isPlaying ? 'playing' : ''}" data-voice-id="${voice.id}">
                <div class="voice-card-header">
                    <div class="avatar-container">
                        <div class="avatar-halo-glow"></div>
                        <div class="avatar-image ${voice.gender || ''}">
                            <svg viewBox="0 0 24 24"><path d="${silhouettePath}"/></svg>
                        </div>
                    </div>
                    <div class="voice-info">
                        <h3 class="voice-name">${voice.name}</h3>
                        <p class="voice-meta">${voice.language} · ${voice.engine}</p>
                    </div>
                </div>
                <div class="voice-card-tags">
                    ${tags.slice(0, 3).map(tag => `<span class="voice-tag">${tag}</span>`).join('')}
                </div>
                <button type="button" class="play-btn" data-voice-id="${voice.id}" aria-label="Play ${voice.name}">
                    <svg class="play-icon" viewBox="0 0 24 24" width="20" height="20">
                        <polygon points="5,3 19,12 5,21" fill="currentColor"/>
                    </svg>
                    <span class="play-text">Play</span>
                </button>
            </div>
        `;
    }).join('');

    // Add click listeners to play buttons
    voiceResults.querySelectorAll('.play-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            playVoice(btn.dataset.voiceId);
        });
    });
}

/**
 * Update results count display
 */
function updateResultsCount() {
    const total = allVoices.length;
    const shown = filteredVoices.length;

    if (shown === total) {
        resultsCount.textContent = `Showing all ${total} voices`;
    } else {
        resultsCount.textContent = `Showing ${shown} of ${total} voices`;
    }
}

/**
 * Shuffle the displayed voices
 */
function shuffleVoices() {
    filteredVoices = filteredVoices.sort(() => Math.random() - 0.5);
    renderVoiceCards();
}

/**
 * Clear all filters
 */
function clearFilters() {
    activeFilters = {
        language: [],
        gender: [],
        engine: [],
        tone: [],
        useCase: []
    };

    // Uncheck all checkboxes
    document.querySelectorAll('.filter-sidebar input[type="checkbox"]').forEach(cb => {
        cb.checked = false;
    });

    applyFilters();
}

/**
 * Play script with selected voice
 */
async function playVoice(voiceId) {
    const script = scriptInput.value.trim();

    if (!script) {
        showError('Please enter a script first');
        scriptInput.focus();
        return;
    }

    const voice = allVoices.find(v => v.id === voiceId);
    if (!voice) return;

    // Stop current playback
    if (audioElement.src) {
        audioElement.pause();
        audioElement.src = '';
    }

    // Update UI - set loading state
    const card = voiceResults.querySelector(`[data-voice-id="${voiceId}"]`);
    const playBtn = card?.querySelector('.play-btn');

    // Remove playing state from all cards
    voiceResults.querySelectorAll('.voice-card').forEach(c => {
        c.classList.remove('playing', 'loading');
    });

    // Set loading state
    card?.classList.add('loading');
    if (playBtn) {
        playBtn.innerHTML = '<div class="loading-spinner"></div><span class="play-text">Loading...</span>';
        playBtn.disabled = true;
    }

    // Update player bar
    playerVoiceName.textContent = `Loading ${voice.name}...`;
    playerAvatar.className = `player-avatar ${voice.gender || ''}`;
    playerAvatarContainer.classList.remove('speaking');
    playerLoading.hidden = false;
    playerPlayBtn.disabled = true;

    try {
        // Generate TTS
        const response = await fetch(`${API_BASE_URL}/generate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                voiceId: voice.id,
                text: script
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Generation failed');
        }

        // Convert base64 to audio
        const audioBlob = base64ToBlob(data.audio, 'audio/mpeg');
        const audioUrl = URL.createObjectURL(audioBlob);

        // Play audio
        audioElement.src = audioUrl;
        await audioElement.play();

        currentlyPlayingId = voiceId;
        card?.classList.remove('loading');
        card?.classList.add('playing');
        playerVoiceName.textContent = voice.name;
        playerPlayBtn.disabled = false;
        playerAvatarContainer.classList.add('speaking');
        updatePlayPauseIcon(true);

    } catch (error) {
        console.error('Playback error:', error);
        showError(error.message || 'Failed to generate audio');
        card?.classList.remove('loading');
        playerVoiceName.textContent = 'Select a voice to preview';
        currentlyPlayingId = null;
    } finally {
        playerLoading.hidden = true;

        // Restore play button
        if (playBtn) {
            playBtn.innerHTML = `
                <svg class="play-icon" viewBox="0 0 24 24" width="20" height="20">
                    <polygon points="5,3 19,12 5,21" fill="currentColor"/>
                </svg>
                <span class="play-text">Play</span>
            `;
            playBtn.disabled = false;
        }
    }
}

/**
 * Toggle play/pause
 */
function togglePlayPause() {
    if (!audioElement.src) return;

    if (audioElement.paused) {
        audioElement.play();
    } else {
        audioElement.pause();
    }
}

/**
 * Update play/pause icon
 */
function updatePlayPauseIcon(isPlaying) {
    playIcon.style.display = isPlaying ? 'none' : 'block';
    pauseIcon.style.display = isPlaying ? 'block' : 'none';
}

/**
 * Convert base64 to Blob
 */
function base64ToBlob(base64, mimeType) {
    const byteChars = atob(base64);
    const byteNumbers = new Array(byteChars.length);
    for (let i = 0; i < byteChars.length; i++) {
        byteNumbers[i] = byteChars.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mimeType });
}

/**
 * Setup audio element listeners
 */
function setupAudioListeners() {
    audioElement.addEventListener('timeupdate', () => {
        if (audioElement.duration) {
            const progress = (audioElement.currentTime / audioElement.duration) * 100;
            playerSeek.value = progress;
            playerCurrent.textContent = formatTime(audioElement.currentTime);
        }
    });

    audioElement.addEventListener('loadedmetadata', () => {
        playerDuration.textContent = formatTime(audioElement.duration);
    });

    audioElement.addEventListener('play', () => {
        updatePlayPauseIcon(true);
        playerAvatarContainer.classList.add('speaking');
    });

    audioElement.addEventListener('pause', () => {
        updatePlayPauseIcon(false);
        playerAvatarContainer.classList.remove('speaking');
    });

    audioElement.addEventListener('ended', () => {
        currentlyPlayingId = null;
        voiceResults.querySelectorAll('.voice-card').forEach(c => {
            c.classList.remove('playing');
        });
        playerVoiceName.textContent = 'Select a voice to preview';
        playerAvatarContainer.classList.remove('speaking');
        updatePlayPauseIcon(false);
        playerSeek.value = 0;
        playerCurrent.textContent = '0:00';
    });

    audioElement.addEventListener('error', (e) => {
        // Only show error if we actually have a source and it failed
        // Setting src='' to stop playback triggers an error we should ignore
        if (audioElement.src && audioElement.src !== window.location.href) {
            console.error('Audio error:', e);
            showError('Audio playback error');
        }
    });
}

/**
 * Setup UI event listeners
 */
function setupEventListeners() {
    // Script input
    scriptInput.addEventListener('input', () => {
        updateCharCount();
        localStorage.setItem('audition_script', scriptInput.value);
    });

    clearScriptBtn.addEventListener('click', () => {
        scriptInput.value = '';
        updateCharCount();
        localStorage.removeItem('audition_script');
    });

    // Filter checkboxes
    document.querySelectorAll('.filter-sidebar input[type="checkbox"]').forEach(checkbox => {
        checkbox.addEventListener('change', (e) => {
            const filterName = e.target.name;
            const filterValue = e.target.value;

            if (e.target.checked) {
                activeFilters[filterName].push(filterValue);
            } else {
                activeFilters[filterName] = activeFilters[filterName].filter(v => v !== filterValue);
            }

            applyFilters();
        });
    });

    // Clear filters buttons
    clearFiltersBtn.addEventListener('click', clearFilters);
    clearFiltersEmptyBtn.addEventListener('click', clearFilters);

    // Shuffle button
    shuffleBtn.addEventListener('click', shuffleVoices);

    // Audio player controls
    playerPlayBtn.addEventListener('click', togglePlayPause);

    playerSeek.addEventListener('input', () => {
        if (audioElement.duration) {
            audioElement.currentTime = (playerSeek.value / 100) * audioElement.duration;
        }
    });

    playerVolume.addEventListener('input', () => {
        audioElement.volume = playerVolume.value / 100;
    });

    // Error toast close
    errorToast.querySelector('.toast-close')?.addEventListener('click', hideError);
}

/**
 * Update character count display
 */
function updateCharCount() {
    const count = scriptInput.value.length;
    charCount.textContent = `${count} / 3000`;
}

/**
 * Format time as M:SS
 */
function formatTime(seconds) {
    if (!seconds || isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

/**
 * Show error toast
 */
function showError(message) {
    errorMessage.textContent = message;
    errorToast.hidden = false;
    setTimeout(hideError, 5000);
}

/**
 * Hide error toast
 */
function hideError() {
    errorToast.hidden = true;
}

// Initialize on load
document.addEventListener('DOMContentLoaded', init);
