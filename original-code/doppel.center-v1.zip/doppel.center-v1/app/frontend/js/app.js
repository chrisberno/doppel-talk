/**
 * Main application initialization module
 * Handles API fetching and orchestrates other modules
 */

import { renderVoices } from './voices.js';
import { initializeFilters } from './filters.js';
import { initializeExportModal } from './export.js';

// API Configuration
// Read from global, data attribute on body, or default to production API
const API_BASE_URL = window.API_BASE_URL
    || document.body.dataset.apiBaseUrl
    || 'https://doppel.center/api';

// DOM Elements
const loadingState = document.getElementById('loading-state');
const errorState = document.getElementById('error-state');
const errorMessage = document.getElementById('error-message');
const retryBtn = document.getElementById('retry-btn');
const voiceGrid = document.getElementById('voice-grid');

// Global state
let allVoices = [];

/**
 * Show loading state
 */
function showLoading() {
    loadingState.hidden = false;
    errorState.hidden = true;
    voiceGrid.hidden = true;
}

/**
 * Hide loading state
 */
function hideLoading() {
    loadingState.hidden = true;
}

/**
 * Show error state with message
 * @param {string} message - Error message to display
 */
function showError(message) {
    hideLoading();
    errorState.hidden = false;
    voiceGrid.hidden = true;
    errorMessage.textContent = message;
}

/**
 * Hide error state
 */
function hideError() {
    errorState.hidden = true;
}

/**
 * Fetch all voices from the API
 * @returns {Promise<Array>} Array of voice objects
 */
async function fetchVoices() {
    const response = await fetch(`${API_BASE_URL}/voices`);

    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data.voices || [];
}

/**
 * Initialize the audio player and related components
 */
function initializeAudio() {
    if (window.audioPlayer) {
        // Initialize the audio player
        window.audioPlayer.initialize();

        // Initialize credentials modal
        window.audioPlayer.initializeCredentialsModal();
    }
}

/**
 * Initialize the application
 */
async function init() {
    // Initialize audio player first (doesn't depend on API)
    initializeAudio();

    // Initialize export modal
    initializeExportModal();

    showLoading();

    try {
        // Fetch all voices
        allVoices = await fetchVoices();

        hideLoading();
        hideError();
        voiceGrid.hidden = false;

        // Render initial voice cards
        renderVoices(allVoices);

        // Initialize filters with all voices
        initializeFilters(allVoices);

    } catch (error) {
        console.error('Failed to fetch voices:', error);
        showError('Failed to load voices. Please check that the backend server is running.');
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', init);

// Retry button handler
retryBtn.addEventListener('click', init);

// Export for other modules
export { allVoices, API_BASE_URL };
