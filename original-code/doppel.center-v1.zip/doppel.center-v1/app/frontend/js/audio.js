/**
 * Audio Player Module
 *
 * Provides two-tier audio playback:
 * 1. Static sample playback (no auth required)
 * 2. Dynamic TTS generation via House Account (no credentials required)
 * 3. Optional pass-through mode if user has saved Twilio credentials
 */

// API Configuration
// Reads from global, data attribute, or defaults to production API
const API_BASE_URL = window.API_BASE_URL
    || document.body.dataset.apiBaseUrl
    || 'https://doppel.center/api';

// Audio player state
const audioState = {
  audioElement: null,
  currentVoiceId: null,
  isPlaying: false,
  isLoading: false,
  volume: 1.0,
  currentTime: 0,
  duration: 0
};

// Credential storage keys
const CREDENTIALS_KEY = 'doppel_credentials';
const SCRIPT_KEY = 'doppel_script';
const VOLUME_KEY = 'doppel_volume';

/**
 * Initialize the audio player
 */
function initializeAudioPlayer() {
  // Create audio element
  audioState.audioElement = new Audio();

  // Load saved volume preference
  const savedVolume = localStorage.getItem(VOLUME_KEY);
  if (savedVolume !== null) {
    audioState.volume = parseFloat(savedVolume);
    audioState.audioElement.volume = audioState.volume;
  }

  // Set up audio event listeners
  audioState.audioElement.addEventListener('play', handlePlay);
  audioState.audioElement.addEventListener('pause', handlePause);
  audioState.audioElement.addEventListener('ended', handleEnded);
  audioState.audioElement.addEventListener('timeupdate', handleTimeUpdate);
  audioState.audioElement.addEventListener('loadedmetadata', handleLoadedMetadata);
  audioState.audioElement.addEventListener('error', handleAudioError);
  audioState.audioElement.addEventListener('waiting', () => setLoadingState(true));
  audioState.audioElement.addEventListener('canplay', () => setLoadingState(false));

  // Initialize UI controls
  initializePlayerControls();

  // Initialize script workspace
  initializeScriptWorkspace();

  // Set up keyboard shortcuts
  setupKeyboardShortcuts();
}

/**
 * Play static sample audio (no credentials required)
 * @param {string} voiceId - Voice ID
 * @param {string} sampleUrl - URL to the sample audio file
 * @param {Object} voiceInfo - Voice metadata for display
 */
async function playSample(voiceId, sampleUrl, voiceInfo = {}) {
  try {
    // Stop current playback if different voice
    if (audioState.currentVoiceId !== voiceId && audioState.isPlaying) {
      stopPlayback();
    }

    audioState.currentVoiceId = voiceId;
    updateNowPlaying(voiceInfo);
    setLoadingState(true);

    // Set audio source and play
    audioState.audioElement.src = sampleUrl;
    audioState.audioElement.load();
    await audioState.audioElement.play();

    setLoadingState(false);
  } catch (error) {
    setLoadingState(false);
    console.error('Sample playback error:', error);
    showAudioError('Failed to play sample audio. Please try again.');
  }
}

/**
 * Play generated audio from custom script
 * Uses House Account mode by default (no credentials required)
 * Falls back to pass-through mode if user has saved credentials
 * @param {string} voiceId - Voice ID
 * @param {string} scriptText - Custom script text
 * @param {Object} voiceInfo - Voice metadata for display
 * @returns {Promise<boolean>} Success status
 */
async function playScript(voiceId, scriptText, voiceInfo = {}) {
  // Validate script
  if (!scriptText || scriptText.trim().length === 0) {
    showAudioError('Please enter a script in the workspace first.');
    return false;
  }

  // Get credentials if available (optional - for pass-through mode)
  const credentials = getCredentials();

  try {
    // Stop current playback if different voice
    if (audioState.currentVoiceId !== voiceId && audioState.isPlaying) {
      stopPlayback();
    }

    audioState.currentVoiceId = voiceId;
    updateNowPlaying(voiceInfo);
    setLoadingState(true);

    // Build request body - omit credentials for house account mode
    const requestBody = {
      voiceId,
      text: scriptText
    };

    // Only include credentials if user has them saved (pass-through mode)
    if (credentials) {
      requestBody.credentials = credentials;
    }

    // Call API to generate audio
    const response = await fetch(`${API_BASE_URL}/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });

    const data = await response.json();

    if (!response.ok) {
      setLoadingState(false);
      handleGenerationError(response.status, data);
      return false;
    }

    // Convert base64 to blob URL
    const audioBlob = base64ToBlob(data.audio, 'audio/mpeg');
    const blobUrl = URL.createObjectURL(audioBlob);

    // Play the audio
    audioState.audioElement.src = blobUrl;
    audioState.audioElement.load();
    await audioState.audioElement.play();

    setLoadingState(false);
    return true;
  } catch (error) {
    setLoadingState(false);
    console.error('Script playback error:', error);
    showAudioError('Failed to generate audio. Please check your connection and try again.');
    return false;
  }
}

/**
 * Stop current playback
 */
function stopPlayback() {
  if (audioState.audioElement) {
    audioState.audioElement.pause();
    audioState.audioElement.currentTime = 0;
  }
  audioState.isPlaying = false;
  audioState.currentTime = 0;
  updatePlayButton(false);
  updateProgress(0, audioState.duration);
}

/**
 * Toggle play/pause
 */
function togglePlayback() {
  if (!audioState.audioElement.src) return;

  if (audioState.isPlaying) {
    audioState.audioElement.pause();
  } else {
    audioState.audioElement.play();
  }
}

/**
 * Seek to specific time
 * @param {number} time - Time in seconds
 */
function seekTo(time) {
  if (audioState.audioElement && audioState.duration > 0) {
    audioState.audioElement.currentTime = Math.max(0, Math.min(time, audioState.duration));
  }
}

/**
 * Set volume
 * @param {number} volume - Volume level (0-1)
 */
function setVolume(volume) {
  audioState.volume = Math.max(0, Math.min(1, volume));
  if (audioState.audioElement) {
    audioState.audioElement.volume = audioState.volume;
  }
  localStorage.setItem(VOLUME_KEY, audioState.volume.toString());
  updateVolumeUI(audioState.volume);
}

// Event handlers
function handlePlay() {
  audioState.isPlaying = true;
  updatePlayButton(true);
  updateVoiceCardPlayingState(audioState.currentVoiceId, true);
}

function handlePause() {
  audioState.isPlaying = false;
  updatePlayButton(false);
}

function handleEnded() {
  audioState.isPlaying = false;
  audioState.currentTime = 0;
  updatePlayButton(false);
  updateProgress(0, audioState.duration);
  updateVoiceCardPlayingState(audioState.currentVoiceId, false);
}

function handleTimeUpdate() {
  audioState.currentTime = audioState.audioElement.currentTime;
  updateProgress(audioState.currentTime, audioState.duration);
}

function handleLoadedMetadata() {
  audioState.duration = audioState.audioElement.duration;
  updateProgress(0, audioState.duration);
}

function handleAudioError(event) {
  console.error('Audio error:', event);
  setLoadingState(false);
  showAudioError('Failed to load audio. The file may be unavailable.');
}

function setLoadingState(isLoading) {
  audioState.isLoading = isLoading;
  const loadingIndicator = document.getElementById('audio-loading');
  const playButton = document.getElementById('audio-play-btn');

  if (loadingIndicator) {
    loadingIndicator.style.display = isLoading ? 'block' : 'none';
  }
  if (playButton) {
    playButton.disabled = isLoading;
  }
}

// UI update functions
function updatePlayButton(isPlaying) {
  const playButton = document.getElementById('audio-play-btn');
  if (playButton) {
    playButton.innerHTML = isPlaying
      ? '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="6" y="4" width="4" height="16" fill="currentColor"/><rect x="14" y="4" width="4" height="16" fill="currentColor"/></svg>'
      : '<svg viewBox="0 0 24 24" width="24" height="24"><polygon points="5,3 19,12 5,21" fill="currentColor"/></svg>';
    playButton.setAttribute('aria-label', isPlaying ? 'Pause' : 'Play');
  }
}

function updateProgress(current, duration) {
  const progressBar = document.getElementById('audio-progress');
  const currentTimeEl = document.getElementById('audio-current-time');
  const durationEl = document.getElementById('audio-duration');

  if (progressBar && duration > 0) {
    progressBar.value = (current / duration) * 100;
  }

  if (currentTimeEl) {
    currentTimeEl.textContent = formatTime(current);
  }

  if (durationEl) {
    durationEl.textContent = formatTime(duration);
  }
}

function updateVolumeUI(volume) {
  const volumeSlider = document.getElementById('audio-volume');
  const volumeIcon = document.getElementById('volume-icon');

  if (volumeSlider) {
    volumeSlider.value = volume * 100;
  }

  if (volumeIcon) {
    if (volume === 0) {
      volumeIcon.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z" fill="currentColor"/></svg>';
    } else if (volume < 0.5) {
      volumeIcon.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20"><path d="M18.5 12c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM5 9v6h4l5 5V4L9 9H5z" fill="currentColor"/></svg>';
    } else {
      volumeIcon.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z" fill="currentColor"/></svg>';
    }
  }
}

function updateNowPlaying(voiceInfo) {
  const nameEl = document.getElementById('now-playing-name');
  const providerEl = document.getElementById('now-playing-provider');

  if (nameEl) {
    nameEl.textContent = voiceInfo.name || 'Unknown Voice';
  }

  if (providerEl) {
    providerEl.textContent = voiceInfo.provider || '';
  }
}

function updateVoiceCardPlayingState(voiceId, isPlaying) {
  // Remove playing state from all cards
  document.querySelectorAll('.voice-card').forEach(card => {
    card.classList.remove('is-playing');
  });

  // Add playing state to current card
  if (isPlaying && voiceId) {
    const currentCard = document.querySelector(`.voice-card[data-voice-id="${voiceId}"]`);
    if (currentCard) {
      currentCard.classList.add('is-playing');
    }
  }
}

// Player controls initialization
function initializePlayerControls() {
  // Play/pause button
  const playButton = document.getElementById('audio-play-btn');
  if (playButton) {
    playButton.addEventListener('click', togglePlayback);
  }

  // Progress bar
  const progressBar = document.getElementById('audio-progress');
  if (progressBar) {
    progressBar.addEventListener('input', (e) => {
      const percent = parseFloat(e.target.value);
      seekTo((percent / 100) * audioState.duration);
    });
  }

  // Volume slider
  const volumeSlider = document.getElementById('audio-volume');
  if (volumeSlider) {
    volumeSlider.value = audioState.volume * 100;
    volumeSlider.addEventListener('input', (e) => {
      setVolume(parseFloat(e.target.value) / 100);
    });
  }

  // Initialize volume UI
  updateVolumeUI(audioState.volume);
}

// Script workspace
function initializeScriptWorkspace() {
  const textarea = document.getElementById('script-textarea');
  const charCounter = document.getElementById('script-char-count');
  const clearButton = document.getElementById('script-clear-btn');

  if (textarea) {
    // Load saved script
    const savedScript = sessionStorage.getItem(SCRIPT_KEY);
    if (savedScript) {
      textarea.value = savedScript;
      updateCharCounter(savedScript.length);
      updatePreviewButtonVisibility(savedScript.length > 0);
    }

    // Save on input (debounced)
    let saveTimeout;
    textarea.addEventListener('input', (e) => {
      const text = e.target.value;
      updateCharCounter(text.length);
      updatePreviewButtonVisibility(text.length > 0);

      clearTimeout(saveTimeout);
      saveTimeout = setTimeout(() => {
        sessionStorage.setItem(SCRIPT_KEY, text);
      }, 300);
    });
  }

  if (clearButton) {
    clearButton.addEventListener('click', () => {
      if (textarea) {
        textarea.value = '';
        updateCharCounter(0);
        updatePreviewButtonVisibility(false);
        sessionStorage.removeItem(SCRIPT_KEY);
      }
    });
  }
}

function updateCharCounter(length) {
  const charCounter = document.getElementById('script-char-count');
  if (charCounter) {
    charCounter.textContent = `${length} / 3000`;
    charCounter.classList.toggle('near-limit', length > 2400);
    charCounter.classList.toggle('at-limit', length >= 3000);
  }
}

function updatePreviewButtonVisibility(hasScript) {
  document.querySelectorAll('.preview-script-btn').forEach(btn => {
    btn.style.display = hasScript ? 'inline-flex' : 'none';
  });
}

// Keyboard shortcuts
function setupKeyboardShortcuts() {
  document.addEventListener('keydown', (e) => {
    // Don't trigger shortcuts when typing in inputs
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
      return;
    }

    switch (e.code) {
      case 'Space':
        e.preventDefault();
        togglePlayback();
        break;
      case 'ArrowLeft':
        e.preventDefault();
        seekTo(audioState.currentTime - 5);
        break;
      case 'ArrowRight':
        e.preventDefault();
        seekTo(audioState.currentTime + 5);
        break;
    }
  });
}

// Credential management
function getCredentials() {
  try {
    const stored = sessionStorage.getItem(CREDENTIALS_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error('Error reading credentials:', e);
  }
  return null;
}

function setCredentials(accountSid, authToken) {
  if (!validateCredentialFormat(accountSid, authToken)) {
    return false;
  }

  try {
    sessionStorage.setItem(CREDENTIALS_KEY, JSON.stringify({
      accountSid,
      authToken
    }));
    return true;
  } catch (e) {
    console.error('Error storing credentials:', e);
    return false;
  }
}

function clearCredentials() {
  sessionStorage.removeItem(CREDENTIALS_KEY);
}

function validateCredentialFormat(accountSid, authToken) {
  if (!accountSid || !accountSid.startsWith('AC') || accountSid.length !== 34) {
    return false;
  }
  if (!authToken || authToken.length !== 32) {
    return false;
  }
  return true;
}

// Credentials modal
function showCredentialsModal() {
  const modal = document.getElementById('credentials-modal');
  if (modal) {
    modal.classList.add('is-visible');
    const sidInput = document.getElementById('cred-account-sid');
    if (sidInput) {
      sidInput.focus();
    }
  }
}

function hideCredentialsModal() {
  const modal = document.getElementById('credentials-modal');
  if (modal) {
    modal.classList.remove('is-visible');
    // Clear inputs
    const sidInput = document.getElementById('cred-account-sid');
    const tokenInput = document.getElementById('cred-auth-token');
    if (sidInput) sidInput.value = '';
    if (tokenInput) tokenInput.value = '';
  }
}

function initializeCredentialsModal() {
  const modal = document.getElementById('credentials-modal');
  const form = document.getElementById('credentials-form');
  const cancelBtn = document.getElementById('cred-cancel-btn');
  const forgetLink = document.getElementById('cred-forget-link');

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const accountSid = document.getElementById('cred-account-sid').value.trim();
      const authToken = document.getElementById('cred-auth-token').value.trim();

      if (setCredentials(accountSid, authToken)) {
        hideCredentialsModal();
        // Update UI to show credentials are stored
        updateCredentialsStatus(true);
      } else {
        showCredentialsError('Invalid credential format. Account SID must start with "AC" and be 34 characters. Auth Token must be 32 characters.');
      }
    });
  }

  if (cancelBtn) {
    cancelBtn.addEventListener('click', hideCredentialsModal);
  }

  if (forgetLink) {
    forgetLink.addEventListener('click', (e) => {
      e.preventDefault();
      clearCredentials();
      updateCredentialsStatus(false);
      hideCredentialsModal();
    });
  }

  // Close on backdrop click
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        hideCredentialsModal();
      }
    });
  }

  // Update initial status
  updateCredentialsStatus(!!getCredentials());
}

function updateCredentialsStatus(hasCredentials) {
  const statusEl = document.getElementById('credentials-status');
  if (statusEl) {
    statusEl.textContent = hasCredentials ? 'Credentials saved' : 'No credentials';
    statusEl.classList.toggle('has-credentials', hasCredentials);
  }
}

function showCredentialsError(message) {
  const errorEl = document.getElementById('cred-error');
  if (errorEl) {
    errorEl.textContent = message;
    errorEl.style.display = 'block';
  }
}

// Error handling
function handleGenerationError(status, data) {
  const errorCode = data.code || '';

  switch (status) {
    case 401:
      clearCredentials();
      updateCredentialsStatus(false);
      // Provide specific guidance based on error code
      if (errorCode === 'INVALID_ACCOUNT_SID') {
        showAudioError(
          'Invalid Account SID format. Must start with "AC" and be 34 characters. ' +
          'Find yours at console.twilio.com',
          'error'
        );
      } else if (errorCode === 'INVALID_AUTH_TOKEN') {
        showAudioError(
          'Invalid Auth Token format. Must be 32 characters. ' +
          'Find yours at console.twilio.com',
          'error'
        );
      } else {
        showAudioError(
          'Invalid credentials. Please re-enter your Twilio credentials. ' +
          'Get them at console.twilio.com',
          'error'
        );
      }
      showCredentialsModal();
      break;
    case 404:
      showAudioError(
        'Voice not found. Try refreshing the page to reload the voice list.',
        'warning'
      );
      break;
    case 400:
      // Parse specific validation errors
      if (errorCode === 'TEXT_TOO_LONG') {
        const maxLength = data.maxLength || 3000;
        const actualLength = data.actualLength || 'unknown';
        showAudioError(
          `Script too long (${actualLength} chars). Maximum is ${maxLength} characters.`,
          'warning'
        );
      } else if (errorCode === 'MISSING_TEXT') {
        showAudioError('Please enter a script in the workspace first.', 'warning');
      } else {
        showAudioError(data.error || 'Invalid request. Please check your script.', 'warning');
      }
      break;
    case 501:
      showAudioError(
        'TTS generation is not yet available for this provider. Try sample audio instead.',
        'warning'
      );
      break;
    case 502:
    case 503:
      // Provider/network errors - suggest retry
      showAudioError(
        'Service temporarily unavailable. Please try again in a moment.',
        'error',
        true // Show retry hint
      );
      break;
    default:
      showAudioError(
        data.error || 'Failed to generate audio. Please check your connection and try again.',
        'error'
      );
  }
}

/**
 * Display an error message to the user
 * @param {string} message - Error message to display
 * @param {string} severity - 'error' or 'warning' (affects styling)
 * @param {boolean} showRetryHint - Whether to suggest retrying
 */
function showAudioError(message, severity = 'error', showRetryHint = false) {
  const errorEl = document.getElementById('audio-error');
  if (errorEl) {
    let displayMessage = message;
    if (showRetryHint) {
      displayMessage += ' Click play to retry.';
    }

    errorEl.textContent = displayMessage;
    errorEl.classList.remove('is-warning', 'is-error');
    errorEl.classList.add('is-visible', severity === 'warning' ? 'is-warning' : 'is-error');

    // Auto-hide after appropriate time based on message length
    const hideDelay = Math.max(5000, message.length * 50);
    setTimeout(() => {
      errorEl.classList.remove('is-visible');
    }, hideDelay);
  }
}

// Utility functions
function formatTime(seconds) {
  if (!seconds || !isFinite(seconds)) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function base64ToBlob(base64, mimeType) {
  const byteCharacters = atob(base64);
  const byteNumbers = new Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);
  return new Blob([byteArray], { type: mimeType });
}

/**
 * Get the current script text
 * @returns {string} Current script text
 */
function getScriptText() {
  const textarea = document.getElementById('script-textarea');
  return textarea ? textarea.value : '';
}

/**
 * Check if there's a script in the workspace
 * @returns {boolean}
 */
function hasScript() {
  return getScriptText().trim().length > 0;
}

// Export functions
window.audioPlayer = {
  initialize: initializeAudioPlayer,
  playSample,
  playScript,
  stopPlayback,
  togglePlayback,
  seekTo,
  setVolume,
  getCredentials,
  setCredentials,
  clearCredentials,
  showCredentialsModal,
  hideCredentialsModal,
  initializeCredentialsModal,
  getScriptText,
  hasScript,
  getState: () => ({ ...audioState })
};
