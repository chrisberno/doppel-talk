# Doppel Center - Product Specification

**Version:** 0.1 (Draft)
**Last Updated:** 2025-12-23
**Status:** Planning
**Owner:** Christopher Berno
**Domain:** doppel.center
**Google Doc:** https://docs.google.com/document/d/1MXcOffCr8grEd2vU6Fj4p5zEpI8HHuu60udvEAsyBrA/edit

---

## Executive Summary

Doppel Center is a provider-agnostic voice talent gallery and configuration tool for IVR and contact center applications. It allows users to browse, preview, compare, and select TTS voices from multiple providers through a unified, premium interface.

**Long-term vision:** Evolve into a full voice production studio with zero-shot voice cloning capabilities (VoiceCraft integration).

---

## Project Identity

| Field | Value |
|-------|-------|
| Project Name | Doppel Center |
| Domain | doppel.center |
| Parent Organization | chrisberno.dev |
| Repository | ~/projects/chrisberno.dev/doppel-center |
| Design System | Twilio Paste (design tokens, HTML/CSS) |

---

## Phase 1: Voice Talent Gallery (MVP)

### Core Features

1. **Voice Library Grid**
   - Card-based layout displaying available voices
   - Each card shows: name, provider, gender, language, accent, tone tags
   - Click-to-preview with standard sample phrase
   - Visual provider badges (Twilio, ElevenLabs, Hume, etc.)

2. **Filtering & Search**
   - Filter by: provider, gender, language, accent, tone/style
   - Free-text search across voice names and descriptions
   - Sort by: name, provider, popularity, newest

3. **Voice Preview**
   - Standard greeting sample for quick comparison
   - Audio player with play/pause, scrub, volume
   - Side-by-side comparison mode (2-3 voices)

4. **Custom Script Input**
   - Textarea to paste custom IVR script
   - "Generate Preview" button
   - Hear selected voice read the full script
   - Download generated audio (MP3/WAV)

5. **Voice Selection/Export**
   - Select a voice → copy configuration snippet
   - Export formats: Twilio Studio JSON, TwiML, API config
   - Save favorites (local storage initially)

### Supported Providers (Phase 1)

| Provider | Voice Count | Notes |
|----------|-------------|-------|
| Twilio (Polly) | ~60+ | Amazon Polly voices via Twilio |
| Twilio (Standard) | ~20 | Legacy Twilio voices |
| ElevenLabs | TBD | API integration |
| Hume AI | TBD | Emotional TTS |
| Amazon Polly (direct) | ~60+ | Direct integration option |
| Google Cloud TTS | TBD | Future consideration |

### Technical Architecture

```
┌─────────────────────────────────────────────────┐
│                  FRONTEND                        │
│         (HTML + Paste Design Tokens)             │
│                                                  │
│  ┌─────────┐  ┌─────────┐  ┌─────────────────┐  │
│  │ Voice   │  │ Filter  │  │ Script Preview  │  │
│  │ Gallery │  │ Sidebar │  │ Panel           │  │
│  └─────────┘  └─────────┘  └─────────────────┘  │
└──────────────────────┬──────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────┐
│                  BACKEND API                     │
│              (Node.js / Express)                 │
│                                                  │
│  ┌─────────────────────────────────────────────┐│
│  │           Voice Registry Service            ││
│  │  (Unified voice metadata from providers)    ││
│  └─────────────────────────────────────────────┘│
│                                                  │
│  ┌─────────────────────────────────────────────┐│
│  │         TTS Generation Service              ││
│  │  (Routes requests to appropriate provider)  ││
│  └─────────────────────────────────────────────┘│
└──────────────────────┬──────────────────────────┘
                       │
        ┌──────────────┼──────────────┐
        ▼              ▼              ▼
   ┌─────────┐   ┌──────────┐   ┌─────────┐
   │ Twilio  │   │ElevenLabs│   │  Hume   │
   │   API   │   │   API    │   │   API   │
   └─────────┘   └──────────┘   └─────────┘
```

### Data Model

```typescript
interface Voice {
  id: string;                    // Unique identifier
  provider: Provider;            // twilio | elevenlabs | hume | polly
  providerVoiceId: string;       // Provider's native voice ID
  name: string;                  // Display name (e.g., "Joanna")
  gender: 'male' | 'female' | 'neutral';
  language: string;              // ISO language code (en-US, es-MX)
  accent?: string;               // British, Australian, etc.
  tags: string[];                // warm, professional, friendly, etc.
  sampleUrl?: string;            // Pre-generated sample audio URL
  previewText: string;           // Default text for preview
  pricing?: PricingTier;         // free | standard | premium
}

interface Provider {
  id: string;
  name: string;
  logo: string;
  apiConfigured: boolean;
  voiceCount: number;
}

interface GenerationRequest {
  voiceId: string;
  text: string;
  outputFormat: 'mp3' | 'wav';
  ssml?: boolean;
}
```

### UI/UX Reference

- **Design Foundation:** Twilio Paste design tokens
- **Template Reference:** `/Volumes/T9/chrisberno.dev/playground/twilio-dashboard/index-enterprise.html`
- **Card Pattern:** Voice talent cards similar to project cards in enterprise template
- **Color Palette:** Paste grays, blues, with provider-specific accent colors

### API Endpoints (Draft)

```
GET  /api/voices                    # List all voices (with filters)
GET  /api/voices/:id                # Get single voice details
GET  /api/voices/:id/sample         # Get/generate sample audio
POST /api/generate                  # Generate audio from text
GET  /api/providers                 # List configured providers
POST /api/export/:format            # Export voice config
```

---

## Phase 2: Enhanced Preview & Comparison

- A/B comparison mode (hear same script in 2 voices side-by-side)
- Script templates library (common IVR scenarios)
- SSML editor for fine-tuning (pace, emphasis, breaks)
- Usage analytics (which voices are popular)

---

## Phase 3: Voice Cloning Studio (VoiceCraft)

- Upload reference audio (3-10 seconds)
- Zero-shot voice cloning via VoiceCraft
- Generate any script in cloned voice
- Speech editing: fix portions of existing recordings
- Voice profile management (save cloned voices)

**Reference:** VoiceCraft paper & GitHub (jasonppy/VoiceCraft)

---

## Embedding & Integration

Doppel Center is designed to be embedded in other applications:

### iframe Embed
```html
<iframe
  src="https://doppel.center/embed?provider=twilio&callback=https://..."
  width="100%"
  height="600"
></iframe>
```

### API Integration
```javascript
// From connie.plus or dutycall.app
const selectedVoice = await doppelCenter.openPicker({
  providers: ['twilio', 'elevenlabs'],
  onSelect: (voice) => {
    // Returns voice config for Studio Flow
  }
});
```

---

## Open Questions

> These need resolution before/during development:

1. **Authentication:** Do we require login, or anonymous usage with rate limits?

2. **Credential Management:** How do consuming apps provide their own API keys?
   - Option A: User enters their keys in Doppel UI
   - Option B: Proxy through Doppel with usage tracking
   - Option C: Both options available

3. **Audio Storage:**
   - Generate on-demand only?
   - Cache generated audio? For how long?
   - Store in S3/Cloudflare R2?

4. **Provider Priority:** Which providers to integrate first?
   - Twilio (definitely - primary use case)
   - ElevenLabs (high quality, popular)
   - Others?

5. **Monetization:**
   - Free tool?
   - Freemium with usage limits?
   - Part of chrisberno.dev portfolio?

6. **Voice Metadata:** Where does voice metadata come from?
   - Manually curated?
   - Pulled from provider APIs?
   - Community contributed?

---

## Credentials & Environment

### Twilio (chrisberno.dev account)
- Location: Reference DutyCall .env files
- Required: TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN

### ElevenLabs
- Status: TBD
- Required: ELEVENLABS_API_KEY

### Hume AI
- Status: TBD
- Required: HUME_API_KEY

---

## Milestones

| Milestone | Description | Status |
|-----------|-------------|--------|
| M0 | Spec finalized, questions resolved | In Progress |
| M1 | HTML prototype with Paste tokens | Pending |
| M2 | Backend API with Twilio voices | Pending |
| M3 | Voice preview functionality | Pending |
| M4 | Custom script generation | Pending |
| M5 | ElevenLabs integration | Pending |
| M6 | Embed/iframe support | Pending |
| M7 | Production deploy to doppel.center | Pending |

---

## References

- [Twilio Paste Design System](https://paste.twilio.design)
- [Twilio TTS Voices](https://www.twilio.com/docs/voice/twiml/say/text-speech)
- [ElevenLabs API](https://elevenlabs.io/docs)
- [VoiceCraft GitHub](https://github.com/jasonppy/VoiceCraft)
- [VoiceCraft Paper](https://arxiv.org/abs/2403.16973)
- Template: `/Volumes/T9/chrisberno.dev/playground/twilio-dashboard/`

---

*Spec maintained by SPOK | chrisberno.dev*
