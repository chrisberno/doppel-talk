# Doppel Center - Traycer.ai Implementation Prompt

*Copy everything below this line to Traycer.ai*

---

## Project: Doppel Center MVP

You are building **Doppel Center** (doppel.center) - a provider-agnostic voice talent gallery for IVR and contact center applications. This is the MVP (Phase 1: Voice Gallery).

### Project Location
```
/Volumes/T9/chrisberno.dev/playground/doppel-center/
```

### Key Reference Files

Before you begin, read these files in order:

1. `SPEC.md` - Full technical specification (data models, API endpoints, architecture)
2. `BizOps/BUSINESS-MODEL.md` - Business context and customer segments
3. `BizOps/STRATEGIC-VISION.md` - Product roadmap and competitive positioning
4. `BizOps/DECISIONS-LOG.md` - Rationale behind key decisions

### UI Template Reference
```
/Volumes/T9/chrisberno.dev/playground/twilio-dashboard/index-enterprise.html
```
This shows Twilio Paste design tokens used in pure HTML/CSS. Use this as your styling foundation.

---

## What You're Building

### Core Features (MVP)

1. **Voice Library Grid**
   - Card-based layout displaying available voices
   - Each card shows: name, provider, gender, language, accent, tone tags
   - Click-to-preview with standard sample phrase
   - Visual provider badges (Twilio, ElevenLabs, Hume, etc.)

2. **Filtering & Search**
   - Filter by: provider, gender, language, accent, tone/style
   - Free-text search across voice names and descriptions
   - Sort by: name, provider, popularity, newest

3. **Voice Preview**
   - Standard greeting sample for quick comparison
   - Audio player with play/pause, scrub, volume
   - Custom text input → generate preview with selected voice

4. **Configuration Export**
   - Select a voice → copy configuration snippet
   - Export formats: TwiML, Twilio Studio JSON, API config

### NOT in MVP Scope
- User authentication (consuming apps handle this)
- Voice cloning (Phase 2)
- Audio storage (on-demand generation only)
- Script Management System (Phase 3)

---

## Technical Requirements

### Design System: Twilio Paste via HTML/CSS

**CRITICAL:** We use Paste design tokens in HTML/CSS, NOT React components.

Example from the template:
```html
<style>
  :root {
    /* Paste color tokens */
    --paste-color-background-primary: #0263E0;
    --paste-color-text-inverse: #FFFFFF;
    --paste-color-background-body: #F4F4F6;

    /* Paste typography */
    --paste-font-family-text: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;

    /* Paste spacing */
    --paste-space-40: 1rem;
    --paste-space-60: 1.5rem;
  }
</style>
```

Study the template file to understand the card patterns, layouts, and color usage.

### Architecture

```
┌─────────────────────────────────────────────────┐
│                  FRONTEND                        │
│         (HTML + Paste Design Tokens + JS)        │
│                                                  │
│  ┌─────────┐  ┌─────────┐  ┌─────────────────┐  │
│  │ Voice   │  │ Filter  │  │ Preview Panel   │  │
│  │ Gallery │  │ Sidebar │  │ + Custom Input  │  │
│  └─────────┘  └─────────┘  └─────────────────┘  │
└──────────────────────┬──────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────┐
│                  BACKEND API                     │
│              (Node.js / Express)                 │
│                                                  │
│  ┌─────────────────────────────────────────────┐│
│  │           Voice Registry Service            ││
│  │  (Unified voice metadata from providers)    ││
│  └─────────────────────────────────────────────┘│
│                                                  │
│  ┌─────────────────────────────────────────────┐│
│  │         TTS Generation Service              ││
│  │  (Routes requests to appropriate provider)  ││
│  └─────────────────────────────────────────────┘│
└──────────────────────┬──────────────────────────┘
                       │
        ┌──────────────┼──────────────┐
        ▼              ▼              ▼
   ┌─────────┐   ┌──────────┐   ┌─────────┐
   │ Twilio  │   │ElevenLabs│   │  Hume   │
   │   API   │   │   API    │   │   API   │
   └─────────┘   └──────────┘   └─────────┘
```

### Data Models

```typescript
interface Voice {
  id: string;                    // Unique identifier
  provider: 'twilio' | 'elevenlabs' | 'hume' | 'polly';
  providerVoiceId: string;       // Provider's native voice ID
  name: string;                  // Display name (e.g., "Joanna")
  gender: 'male' | 'female' | 'neutral';
  language: string;              // ISO language code (en-US, es-MX)
  accent?: string;               // British, Australian, etc.
  tags: string[];                // warm, professional, friendly, etc.
  sampleUrl?: string;            // Pre-generated sample audio URL
  previewText: string;           // Default text for preview
  pricing?: 'free' | 'standard' | 'premium';
}

interface Provider {
  id: string;
  name: string;
  logo: string;
  apiConfigured: boolean;
  voiceCount: number;
}

interface GenerationRequest {
  voiceId: string;
  text: string;
  outputFormat: 'mp3' | 'wav';
  ssml?: boolean;
}
```

### API Endpoints

```
GET  /api/voices                    # List all voices (with filters)
GET  /api/voices/:id                # Get single voice details
GET  /api/voices/:id/sample         # Get/generate sample audio
POST /api/generate                  # Generate audio from text
GET  /api/providers                 # List configured providers
POST /api/export/:format            # Export voice config (twiml, studio, api)
```

### Provider Priority

For MVP, focus on **Twilio (Polly voices)** first. The architecture should abstract providers so adding ElevenLabs/Hume later is straightforward.

### Credential Model (Must Support All Three)

1. **Pass-through:** Credentials in API request payload (for testing)
2. **BYOK:** Stored encrypted (customer's own provider accounts)
3. **House Account:** Doppel's master credentials (for B2C users)

For MVP, implement pass-through first. Structure the code so BYOK and House Account can be added.

---

## Suggested Directory Structure

```
doppel-center/
├── SPEC.md
├── BizOps/
│   ├── BUSINESS-MODEL.md
│   ├── STRATEGIC-VISION.md
│   └── DECISIONS-LOG.md
├── frontend/
│   ├── index.html
│   ├── css/
│   │   └── styles.css          # Paste design tokens
│   ├── js/
│   │   ├── app.js              # Main application
│   │   ├── voices.js           # Voice gallery logic
│   │   ├── filters.js          # Filter/search logic
│   │   └── audio.js            # Audio player controls
│   └── assets/
│       └── provider-logos/     # Twilio, ElevenLabs, etc.
├── backend/
│   ├── package.json
│   ├── server.js               # Express server entry
│   ├── routes/
│   │   ├── voices.js
│   │   ├── generate.js
│   │   └── export.js
│   ├── services/
│   │   ├── voiceRegistry.js    # Unified voice metadata
│   │   ├── ttsService.js       # Provider abstraction
│   │   └── providers/
│   │       ├── twilio.js
│   │       ├── elevenlabs.js   # Stub for later
│   │       └── hume.js         # Stub for later
│   └── data/
│       └── voices.json         # Static voice catalog (MVP)
└── .env.example
```

---

## Implementation Order

1. **Project Setup**
   - Initialize directory structure
   - Set up backend with Express
   - Create .env.example with required variables

2. **Voice Registry**
   - Create static voices.json with Twilio Polly voices
   - Implement GET /api/voices with filtering
   - Implement GET /api/voices/:id

3. **Frontend Gallery**
   - Build HTML structure with Paste tokens
   - Create voice card components
   - Implement filter sidebar
   - Wire up to backend API

4. **TTS Generation**
   - Implement Twilio provider service
   - Create POST /api/generate endpoint
   - Add audio player to frontend

5. **Export Functionality**
   - Implement POST /api/export/:format
   - Add copy-to-clipboard in frontend

---

## Credentials

For Twilio integration, you'll need:
- `TWILIO_ACCOUNT_SID`
- `TWILIO_AUTH_TOKEN`

Ask the CEO for credentials when ready to test TTS generation.

---

## Questions During Implementation

If you need clarification on:
- **Scope/features** → Ask, I'll check with SPOK
- **Business logic** → Reference the BizOps documents
- **UI patterns** → Reference the twilio-dashboard template
- **Technical decisions** → Use your judgment, document in code comments

---

## Success Criteria

MVP is complete when:
- [ ] Voice gallery displays Twilio Polly voices in card layout
- [ ] Filters work (provider, gender, language)
- [ ] Search works across voice names
- [ ] Click voice → hear sample audio
- [ ] Enter custom text → generate preview
- [ ] Export voice config in at least one format (TwiML)
- [ ] UI matches Twilio Paste design language

---

Let's build this. Start by reading the reference files, then propose your implementation approach before writing code.
