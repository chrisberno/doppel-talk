# Doppel Center - Project Status Document

**Generated:** December 25, 2025
**Last Updated:** December 27, 2025
**Status:** Production - API & Demo Frontend Live

---

## Current State Summary (What's Built & Working)

**Production Deployed** - API and Demo Frontend are live and separated.

### Production URLs

| Component | URL | Host |
|-----------|-----|------|
| **API** | https://doppel.center | Render (chrisberno) |
| **Demo Frontend** | https://voice-demos.doppel.center | Vercel (chris-2413) |
| **GitHub** | https://github.com/chrisberno/doppel-center | - |

### What's Built

| Component | Status | Location |
|-----------|--------|----------|
| Backend API | **Production** | `app/backend/server.js` |
| Voice Registry | Working | `app/backend/services/voiceRegistry.js` |
| TTS Service | Working | `app/backend/services/ttsService.js` |
| Twilio Provider | Working | `app/backend/services/providers/twilio.js` |
| Frontend Gallery | **Production** | `app/frontend/index.html` |
| Filter Sidebar | Working | `app/frontend/js/filters.js` |
| Audio Player | Working | `app/frontend/js/audio.js` |
| Export Service | Working | `app/backend/services/exportService.js` |
| 16 Voice Samples | Working | `app/frontend/assets/audio/samples/` |

### What's Working (Verified in Production)

- Voice listing/filtering: `GET /api/voices`
- **House Account TTS**: `POST /api/generate` (no credentials required!)
- Pass-through TTS: `POST /api/generate` (with user-provided Twilio creds)
- Config exports: `POST /api/export/:format` (TwiML, Studio JSON, API config)
- Responsive UI with Twilio Paste styling
- Health check: `GET /health`
- API info endpoint: `GET /` (returns JSON with endpoint list)

### How to Run

```bash
cd /Volumes/T9/chrisberno.dev/playground/doppel-center/app/backend
node server.js
# Visit http://localhost:3000
```

---

## Phase Breakdown

| Phase | Title | Status |
|-------|-------|--------|
| 1 | Project Setup & Backend Foundation | Completed |
| 2 | Frontend Gallery with Twilio Paste Design | Completed |
| 3 | TTS Generation & Audio Preview | Completed |
| 4 | Configuration Export Functionality | Completed |
| 5 | API Documentation & Production Polish | Completed |

**Key Deliverables per Phase:**
- **Phase 1:** Express server, voice registry, `/api/voices`, `.env.example`
- **Phase 2:** `index.html`, `styles.css`, `voices.js`, `filters.js`, API wiring
- **Phase 3:** `twilio.js`, `ttsService.js`, `/api/generate`, `audio.js`, preview flow
- **Phase 4:** `/api/export/:format`, export modal, syntax highlighting
- **Phase 5:** Error handling, loading states, README, `/api/providers`

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER BROWSER                              │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                         FRONTEND                                 │
│                 frontend/index.html + JS/CSS                     │
│                                                                  │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│   │ Voice        │  │ Filter       │  │ Script Preview       │  │
│   │ Gallery      │  │ Sidebar      │  │ + Audio Player       │  │
│   └──────────────┘  └──────────────┘  └──────────────────────┘  │
└───────────────────────────┬─────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│ GET          │   │ POST         │   │ POST         │
│ /api/voices  │   │ /api/generate│   │ /api/export  │
│              │   │              │   │ /:format     │
└──────┬───────┘   └──────┬───────┘   └──────┬───────┘
       │                  │                  │
       ▼                  ▼                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                      BACKEND API                                 │
│                  backend/server.js                               │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │              Voice Registry Service                      │    │
│  │         backend/services/voiceRegistry.js                │    │
│  │           (16 curated Twilio/Polly voices)               │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                TTS Service                               │    │
│  │           backend/services/ttsService.js                 │    │
│  └────────────────────────┬────────────────────────────────┘    │
│                           │                                      │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │               Export Service                             │    │
│  │          backend/services/exportService.js               │    │
│  └─────────────────────────────────────────────────────────┘    │
└───────────────────────────┬─────────────────────────────────────┘
                            │
                            ▼
                   ┌──────────────────┐
                   │   Twilio TTS API  │
                   │   (AWS Polly)     │
                   └──────────────────┘
```

**Data Flow:**
1. User loads page → Frontend fetches `GET /api/voices` → Filtered list rendered
2. User enters script + creds → `POST /api/generate` → Audio URL returned → Audio plays
3. User clicks export → `POST /api/export/:format` → TwiML/Studio/API config returned

---

## Voice Catalog

16 voices across 4 languages (Neural + Generative engines only):

| Language | Voices |
|----------|--------|
| English (US) | Joanna, Matthew, Ruth, Stephen, Ivy, Joey |
| English (UK) | Amy, Brian, Emma |
| Spanish (US/MX) | Lupe, Pedro, Mia |
| Portuguese (BR) | Camila, Thiago |
| French (FR) | Léa, Rémi |

---

## Key Decisions Made

From `bizops/DECISIONS-LOG.md`:

| Decision | Summary |
|----------|---------|
| DEC-001 | Platform Architecture: API-first, embeddable (iframe/API). No user auth in Doppel. |
| DEC-003 | Credential Model: Pass-through (MVP), BYOK, House Account tiers. |
| DEC-004 | Revenue Model: B2B platform fee (customer pays provider); B2C pays Doppel (markup). |
| DEC-005 | Pricing: No free/freemium. Generous trial → paid (pay-per-use/bundles). |
| DEC-006 | Audio Storage: MVP on-demand only (no storage). |
| DEC-007 | Provider Priority: Twilio/Polly first, then VoiceCraft, ElevenLabs, Hume. |
| DEC-008 | Voice Metadata: Provider APIs for MVP; future AI "Voice Casting". |

**Pending Decisions:** House Account prepay/postpay, trial limits.

---

## Next Steps / Backlog

### Completed (Dec 27, 2025)
- [x] Deploy API to doppel.center (Render)
- [x] Deploy demo frontend to voice-demos.doppel.center (Vercel)
- [x] Implement House Account mode (no credentials required)
- [x] Separate frontend from API (clean architecture)
- [x] Custom script TTS generation working
- [x] Postman collection with House Account tests

### In Progress
- [ ] **Script-First UX Redesign**: User enters script first, then auditions voices
  - Current UX is voice-first (browse voices, then enter script)
  - New UX: Script workspace prominent, voices are audition options

### Phase 2 (from SPEC.md)
- [ ] A/B voice comparison mode
- [ ] SSML editor
- [ ] Script templates library
- [ ] Usage analytics

### Phase 3+ (Strategic)
- [ ] Voice cloning (VoiceCraft integration)
- [ ] Additional providers (ElevenLabs, Hume)
- [ ] BYOK credential storage
- [ ] Usage metering & billing
- [ ] Embed/iframe production support
- [ ] International localization

### Quick Wins
- [ ] Rate limiting for House Account
- [ ] Community voice contributions

---

## Directory Structure

```
doppel-center/
├── app/                        # Deployable code
│   ├── backend/
│   │   ├── server.js           # Express server entry
│   │   ├── routes/
│   │   │   ├── voices.js       # GET /api/voices
│   │   │   ├── generate.js     # POST /api/generate
│   │   │   └── export.js       # POST /api/export/:format
│   │   ├── services/
│   │   │   ├── voiceRegistry.js
│   │   │   ├── ttsService.js
│   │   │   ├── exportService.js
│   │   │   └── providers/
│   │   │       └── twilio.js
│   │   └── data/
│   │       └── voices.json     # 16 voice definitions
│   └── frontend/
│       ├── index.html
│       ├── css/styles.css
│       ├── js/
│       │   ├── voices.js
│       │   ├── filters.js
│       │   └── audio.js
│       └── assets/audio/samples/   # 16 pre-generated MP3s
├── bizops/                     # Business strategy
│   ├── BUSINESS-MODEL.md
│   ├── STRATEGIC-VISION.md
│   └── DECISIONS-LOG.md
├── techops/                    # Technical operations
│   └── PROJECT-STATUS.md       # (this file)
├── scripts/
│   ├── generate-samples.js     # AWS Polly sample generator
│   └── upload-to-gdrive.py     # Google Docs sync script
├── SPEC.md                     # Master specification
├── TRAYCER-PROMPT.md           # Traycer implementation handoff
└── README.md                   # Project README
```

---

## Credentials

Stored in `~/SPOK/credentials/doppel-center.env`:
- Twilio Account SID & Auth Token (doppel.center project)
- AWS Access Key & Secret (Polly access)

---

## Total MVP Effort

5 implementation phases completed. Production-ready MVP.
Start server with `node app/backend/server.js`, visit `http://localhost:3000`.

---

*This is a living document. Updated at end of each work session.*
*Last updated: December 27, 2025*
