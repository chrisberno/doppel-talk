# Doppel Center Postman Collection

API testing collection for Doppel Center - the provider-agnostic voice talent gallery.

## Files

| File | Description |
|------|-------------|
| `doppel-center.postman_collection.json` | Main API collection |
| `doppel-center-production.postman_environment.json` | Production environment (doppel.center) |
| `doppel-center-local.postman_environment.json` | Local development environment |

## Quick Start

1. **Import Collection**: In Postman, click Import → select `doppel-center.postman_collection.json`
2. **Import Environment**: Import the appropriate environment file (Production or Local)
3. **Select Environment**: Choose the environment from the dropdown in top-right
4. **Run Requests**: Start with Health Check to verify connectivity

## Endpoints

### Health
- `GET /health` - Server health check

### Voices (Public - No Auth Required)
- `GET /api/voices` - List all voices
- `GET /api/voices?gender=female` - Filter by gender
- `GET /api/voices?language=en-US` - Filter by language
- `GET /api/voices?engine=neural` - Filter by engine type
- `GET /api/voices/:id` - Get single voice
- `GET /api/providers` - List available providers

### Generate (Requires Twilio Credentials)
- `POST /api/validate-credentials` - Validate Twilio creds
- `POST /api/generate` - Generate TTS audio (returns base64 MP3)

### Export (Public)
- `POST /api/export/twiml` - Export TwiML config
- `POST /api/export/studio` - Export Twilio Studio JSON
- `POST /api/export/api` - Export API code snippet

## Setting Up Credentials

For TTS generation, you need Twilio credentials:

1. Go to your environment settings
2. Set `twilio_account_sid` (starts with "AC", 34 chars)
3. Set `twilio_auth_token` (32 chars)

These are stored as secrets and passed in the request body (pass-through model).

## Test Scripts

Each request includes test scripts that validate:
- Status codes
- Response structure
- Required fields
- Business logic (e.g., filters return correct data)

Run the collection to execute all tests.
