#!/usr/bin/env python3
"""
Upload DOCX file to Google Drive and convert to Google Docs format.
Uses gcloud application default credentials (chris@chrisberno.dev).
"""

import os
import sys
from google.oauth2 import credentials
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
import google.auth

# Define scopes needed
SCOPES = ['https://www.googleapis.com/auth/drive.file']

def get_credentials():
    """Get credentials using application default credentials."""
    creds, project = google.auth.default(scopes=SCOPES)
    return creds

def find_or_create_folder(service, folder_name, parent_id=None):
    """Find a folder by name, or create it if it doesn't exist."""
    query = f"name='{folder_name}' and mimeType='application/vnd.google-apps.folder' and trashed=false"
    if parent_id:
        query += f" and '{parent_id}' in parents"

    results = service.files().list(q=query, fields="files(id, name)").execute()
    files = results.get('files', [])

    if files:
        return files[0]['id']

    # Create folder
    file_metadata = {
        'name': folder_name,
        'mimeType': 'application/vnd.google-apps.folder'
    }
    if parent_id:
        file_metadata['parents'] = [parent_id]

    folder = service.files().create(body=file_metadata, fields='id').execute()
    print(f"Created folder: {folder_name}")
    return folder.get('id')

def upload_docx_as_gdoc(service, file_path, folder_id, doc_name):
    """Upload a DOCX file and convert to Google Docs format."""

    # Check if file already exists in folder
    query = f"name='{doc_name}' and '{folder_id}' in parents and trashed=false"
    results = service.files().list(q=query, fields="files(id, name)").execute()
    existing = results.get('files', [])

    media = MediaFileUpload(
        file_path,
        mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        resumable=True
    )

    if existing:
        # Update existing file
        file_id = existing[0]['id']
        file = service.files().update(
            fileId=file_id,
            media_body=media
        ).execute()
        print(f"Updated existing document: {doc_name}")
    else:
        # Create new file (convert to Google Docs)
        file_metadata = {
            'name': doc_name,
            'parents': [folder_id],
            'mimeType': 'application/vnd.google-apps.document'
        }
        file = service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id, webViewLink'
        ).execute()
        print(f"Created new document: {doc_name}")

    # Get the webViewLink
    file_info = service.files().get(fileId=file.get('id'), fields='webViewLink').execute()
    return file_info.get('webViewLink')

def main():
    if len(sys.argv) < 2:
        print("Usage: python upload-to-gdrive.py <docx_file>")
        sys.exit(1)

    docx_path = sys.argv[1]
    if not os.path.exists(docx_path):
        print(f"File not found: {docx_path}")
        sys.exit(1)

    # Get credentials
    print("Authenticating with Google Drive...")
    creds = get_credentials()
    service = build('drive', 'v3', credentials=creds)

    # Create folder structure: Doppel Center > Documentation
    print("Setting up folder structure...")
    doppel_folder_id = find_or_create_folder(service, 'Doppel Center')
    docs_folder_id = find_or_create_folder(service, 'Documentation', doppel_folder_id)

    # Upload the file
    doc_name = os.path.splitext(os.path.basename(docx_path))[0]
    print(f"Uploading {doc_name}...")
    doc_link = upload_docx_as_gdoc(service, docx_path, docs_folder_id, doc_name)

    print(f"\n✅ Document uploaded successfully!")
    print(f"📄 Google Doc: {doc_link}")

    return doc_link

if __name__ == '__main__':
    main()
