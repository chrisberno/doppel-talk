#!/usr/bin/env node
/**
 * Generate sample MP3 files for all voices using AWS Polly
 *
 * Prerequisites:
 *   npm install @aws-sdk/client-polly
 *   AWS credentials in ~/.aws/credentials
 *
 * Run: node scripts/generate-samples.js
 */

const { PollyClient, SynthesizeSpeechCommand } = require('@aws-sdk/client-polly');
const fs = require('fs');
const path = require('path');

// Load voices data
const voicesData = require('../backend/data/voices.json');

// AWS Polly client (uses credentials from ~/.aws/credentials)
const polly = new PollyClient({ region: 'us-east-1' });

// Output directory
const outputDir = path.join(__dirname, '../frontend/assets/audio/samples');

// Map our voice IDs to AWS Polly voice IDs and engines
function getPollyConfig(voice) {
  // Extract voice name from providerVoiceId (e.g., "Polly.Joanna-Neural" -> "Joanna")
  const match = voice.providerVoiceId.match(/Polly\.(\w+)-(\w+)/);
  if (!match) {
    console.error(`Invalid providerVoiceId format: ${voice.providerVoiceId}`);
    return null;
  }

  const voiceId = match[1]; // e.g., "Joanna"
  const engineType = match[2].toLowerCase(); // e.g., "neural" or "generative"

  // Map engine types to Polly engine values
  let engine;
  if (engineType === 'generative') {
    engine = 'generative';
  } else if (engineType === 'neural') {
    engine = 'neural';
  } else {
    engine = 'standard';
  }

  return { voiceId, engine };
}

async function generateSample(voice) {
  const config = getPollyConfig(voice);
  if (!config) return false;

  const outputPath = path.join(outputDir, `${voice.id}.mp3`);

  console.log(`Generating: ${voice.name} (${config.voiceId}, ${config.engine})...`);

  try {
    const command = new SynthesizeSpeechCommand({
      Engine: config.engine,
      OutputFormat: 'mp3',
      Text: voice.previewText,
      VoiceId: config.voiceId,
      SampleRate: '24000',
    });

    const response = await polly.send(command);

    // Convert stream to buffer
    const chunks = [];
    for await (const chunk of response.AudioStream) {
      chunks.push(chunk);
    }
    const audioBuffer = Buffer.concat(chunks);

    // Write to file
    fs.writeFileSync(outputPath, audioBuffer);

    const sizeKB = (audioBuffer.length / 1024).toFixed(1);
    console.log(`  ✓ Saved: ${voice.id}.mp3 (${sizeKB} KB)`);
    return true;

  } catch (error) {
    console.error(`  ✗ Error generating ${voice.name}: ${error.message}`);
    return false;
  }
}

async function main() {
  console.log('='.repeat(60));
  console.log('Doppel Center - Sample Audio Generator');
  console.log('='.repeat(60));
  console.log(`\nGenerating ${voicesData.voices.length} voice samples...\n`);

  // Ensure output directory exists
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  let success = 0;
  let failed = 0;

  for (const voice of voicesData.voices) {
    const result = await generateSample(voice);
    if (result) {
      success++;
    } else {
      failed++;
    }

    // Small delay to avoid rate limiting
    await new Promise(r => setTimeout(r, 200));
  }

  console.log('\n' + '='.repeat(60));
  console.log(`Complete: ${success} succeeded, ${failed} failed`);
  console.log('='.repeat(60));
}

main().catch(console.error);
